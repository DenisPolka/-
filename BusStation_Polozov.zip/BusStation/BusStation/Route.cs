﻿using System;
using System.Linq;
using System.ComponentModel;

namespace BusStation
{
    // Класс пути.
    public class Route : Point
    {
        // Время отправления.
        public string LeavingTime { get; set; }

        // Время прибытия.
        public string ArrivingTime { get; set; }

        // Номер рейса.
        public int RouteNumber { get; set; }

        // Промежуточные точки.
        public Point[] GoThrough { get; private set; }

        // Колекция свободные места.
        public BindingList<int> FreePlaces { get; set; }

        // Промежуточные точки в виде строке.
        private string goThroughStr;

        // Конструктор.
        public Route() : base()
        {
            // Дефолтные значения.
            LeavingTime = "14:00 10.06";
            ArrivingTime = "14:00 12.06";
            RouteNumber = 1;
            GoThrough = null;
            CreatePlaces();
        }

        // Перегрузка конструктора.
        public Route(int number, string endPoint,
                    string leavingTime, string arrivingTime,
                    double price, string goThrough, string seatsAvailable)
                    : base(endPoint, price)
        {
            RouteNumber = number;
            ArrivingTime = arrivingTime;
            LeavingTime = leavingTime;
            GoThroughStr = goThrough;
            GoThroughQue(goThrough);
            PlacesInColection(seatsAvailable);
        }


        // Количество свободных мест.
        public int TicketsFree
        {
            get
            {
                return FreePlaces.Count;
            }
        }

        // Названия промежуточных точек.
        public string GoThroughStr
        {
            get
            {
                return goThroughStr;
            }
            set
            {
                goThroughStr = value;
                GoThroughQue(value);
            }
        }

        // Преобразование промежуточных точек из строки в массив.
        public void GoThroughQue(string str)
        {
            if (str != null)
            {
                string[] goThrough = str.Split(',');
                GoThrough = new Point[goThrough.Length];
                var length = GoThrough.Length;

                for (var i = 0; i < length; ++i)
                {
                    GoThrough[i] = new Point(goThrough[i]);
                }
            }
        }

        // Преобразование номеров свободных мест из строки в колекцию.
        public void PlacesInColection(string places)
        {
            string[] placesQue = places.Split(',');
            var length = placesQue.Length;
            FreePlaces = new BindingList<int>();

            for (var i = 0; i < length; ++i)
            {
                FreePlaces.Add(int.Parse(placesQue[i]));
            }

            FreePlaces = new BindingList<int>(FreePlaces.OrderBy(n => n).ToList());
        }

        // Преобразование номеров свободных мест из колекции в строку.
        public string PlacesInStr()
        {
            FreePlaces = new BindingList<int>(FreePlaces.OrderBy(n => n).ToList());
            string res = "";

            foreach (var places in FreePlaces)
            {
                res = res + places + ",";
            }

            return res.TrimEnd(',');
        }

        // Создание колекции свободных мест.
        public void CreatePlaces()
        {
            FreePlaces = new BindingList<int>();
            var amountPlaces = 35;

            for (var i = 1; i < amountPlaces + 1; ++i)
            {
                FreePlaces.Add(i);
            }
        }
    }
}
