﻿using System;

namespace BusStation
{
    // Класс информации о билете.
    public class TicketInfo : Route
    {
        // Имя покупателя.
        public string Name { get; set; }

        // Фамилия покупателя.
        public string Surname { get; set; }

        // Код покупателя.
        public string BuyerID { get; set; }

        // Номер купленного места.
        public int Place { get; set; }

        // Состояние билета.
        public string Status { get; set; }

        // Конструктор.
        public TicketInfo(Route data)
        {
            ArrivingTime = data.ArrivingTime;
            LeavingTime = data.LeavingTime;
            EndPointName = data.EndPointName;
            RouteNumber = data.RouteNumber;
            TicketPrice = data.TicketPrice;
        }

        // Перегрузка конструктора.
        public TicketInfo() : base()
        {
            Name = "Ім'я";
            Surname = "Прізвище";
            BuyerID = "Номер";
        }

        // Расчет номера билета.
        public int TicketID
        {
            get
            {
                return Math.Abs((RouteNumber*
                    Name.GetHashCode() * 1000 +
                    EndPointName.GetHashCode() +
                    Surname.GetHashCode() * 2)%10000000);

            }
        }
    }
}
