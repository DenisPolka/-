﻿using System;
using System.ComponentModel;
using Newtonsoft.Json;
using System.IO;
using System.Text;

namespace BusStation
{
    // Класс расписания путей.
    public class RouteList
    {
        // Все существующие пути.
        public BindingList<Route> Routes { get; set; }

        // Отобранные по конечному пункту пути.
        public BindingList<Route> SearchedData { get; set; }

        // Конструктор.
        public RouteList()
        {
            Read();
        }

        // Индексатор.
        public Route this[int i]
        {
            get
            {
                return Routes[i];
            }
            set
            {
                Routes[i] = value;
            }
        }
       
        // Считывание всех путей из файла.
        public void Read()
        {
            Routes = new BindingList<Route>();
            string[,] routeList = JsonConvert.DeserializeObject<string[,]>
                (Encoding.UTF8.GetString(File.ReadAllBytes("RouteList.json")));
            var length = routeList.GetUpperBound(0) + 1;

            if (routeList == null)
            {
                return;
            }

            for (var i = 0; i < length; ++i)
            {
                Route route = new Route(int.Parse(routeList[i, 0]), routeList[i, 1],
                routeList[i, 2], routeList[i, 3], 0, routeList[i, 4], routeList[i, 5]);

                Routes.Add(route);
            }
        }

        // Запись всех путей в файл.
        public void Write()
        {
            string[,] routeList = new string[Routes.Count, 6];

            var n = 0;  // Номер пути.
            foreach (var data in Routes)
            {
                routeList[n, 0] = data.RouteNumber.ToString();
                routeList[n, 1] = data.EndPointName;
                routeList[n, 2] = data.LeavingTime;
                routeList[n, 3] = data.ArrivingTime;
                routeList[n, 4] = data.GoThroughStr;
                routeList[n, 5] = data.PlacesInStr();
                ++n;
            }

            File.WriteAllText("RouteList.json", JsonConvert.SerializeObject(routeList));
        }

        // Поиск пути по конечному пункту.
        public void RoutesByEndPoint(string value, TicketPrice data)
        {
            DateTime now = DateTime.Now;
            DateTime leaving = DateTime.MinValue;
            Route needRoute;
            SearchedData = new BindingList<Route>();           
            var max = 0;
            var length = Routes.Count;
            double cost = data.SearchCost(value);

            for (var i = 0; i < length; ++i)
            {
                Route temp = this[i];

                if (null == temp.GoThrough)
                {
                    max = 1;
                }
                else
                {
                    max = temp.GoThrough.Length;
                }

                for (var j = 0; j < max; ++j)
                {
                    leaving = DateTime.Parse(temp.LeavingTime);

                    if ((temp.EndPointName == value || temp.GoThrough != null && 
                        temp.GoThrough[j].EndPointName == value) && temp.TicketsFree != 0)
                    {
                        needRoute = new Route(temp.RouteNumber, value, temp.LeavingTime,
                            temp.ArrivingTime, cost, null, temp.PlacesInStr());

                        SearchedData.Add(needRoute);
                        break;
                    }
                }
                SortRoutesByDate(SearchedData);
            }
        }

        // Сортировка путей по дате отправления.
        private void SortRoutesByDate(BindingList<Route> data)
        {
            var n = data.Count;
            for (var i = n; i > 1; --i)
            {
                for (var j = 1; j < i; ++j)
                {
                    if (DateInNumber(data[j - 1]) > DateInNumber(data[j]) )
                    {
                        Route temp = data[j - 1];
                        data[j - 1] = data[j];
                        data[j] = temp;
                    }
                }
            }
        }

        // Перевод даты в число(чем больше дата тем больше число).
        private int DateInNumber(Route data)
        {
            var hour = int.Parse(data.LeavingTime.Substring(0, 2));
            var day = int.Parse(data.LeavingTime.Substring(6, 2));
            var month = int.Parse(data.LeavingTime.Substring(9));

            return hour * 321 + day * 543 + month * 9876;
        }
    }
}