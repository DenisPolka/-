﻿using BusStation;
using System;
using System.Windows.Forms;

namespace BusStation
{
    static class Program
    {
        //Головна точка входу для програми.
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            MainForm.Form = new MainForm();
            Application.Run(MainForm.Form);
        }
    }
}
