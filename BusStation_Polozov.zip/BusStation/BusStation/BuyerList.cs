﻿using System;
using System.ComponentModel;
using System.IO;
using Newtonsoft.Json;
using System.Text;
using BusStation;

namespace BusStation
{
    // Класс информации о покупателях.
    public class BuyerList
    {
        // Информация о покупателе.
        public BindingList<TicketInfo> BuyerData { get; set; }

        // Расписание путей.
        RouteList routeList;

        // Конструктор.
        public BuyerList(RouteList list)
        {
            routeList = list;
            Read();
            BuyersDataSort();
        }

        // Считывание информации о покупателях из файла.
        public void Read()
        {
            BuyerData = new BindingList<TicketInfo>();
            string[,] data = JsonConvert.DeserializeObject<string[,]>
                (Encoding.UTF8.GetString(File.ReadAllBytes("BuyerList.json")));
            var length = data.GetUpperBound(0) + 1;
            TicketInfo add;

            if (data == null)
            {
                return;
            }

            for (var i = 0; i < length; ++i)
            {
                 add = new TicketInfo();

                add.RouteNumber = int.Parse(data[i, 0]);
                add.EndPointName = data[i, 1];
                add.Name = data[i, 2];
                add.Surname = data[i, 3];
                add.BuyerID = data[i, 4];
                add.LeavingTime = data[i, 5];
                add.ArrivingTime = data[i, 6];
                add.TicketPrice = int.Parse(data[i, 7]);
                add.Place = int.Parse(data[i, 8]);
                add.Status = SearchStatus(add);

                BuyerData.Add(add);
            }
        }

        // Запись информации о покупателях в файл.
        public void Write()
        {
            string[,] data = new string[BuyerData.Count, 10];

            var n = 0;
            foreach (var ticket in BuyerData)
            {
                data[n, 0] = ticket.RouteNumber.ToString();
                data[n, 1] = ticket.EndPointName;
                data[n, 2] = ticket.Name;
                data[n, 3] = ticket.Surname;
                data[n, 4] = ticket.BuyerID;
                data[n, 5] = ticket.LeavingTime;
                data[n, 6] = ticket.ArrivingTime;
                data[n, 7] = ticket.TicketPrice.ToString();
                data[n, 8] = ticket.Place.ToString();
                data[n, 9] = ticket.Status;
                ++n;
            }

            File.WriteAllText("BuyerList.json",
                JsonConvert.SerializeObject(data));
        }

        // Удаление всех отмененных билетов.
        public void ClearWrong()
        {
            string check = "Скасовано";
            var length = BuyerData.Count;

            for (var i = 0; i < length; ++i)
            {
                if (check == SearchStatus(BuyerData[i]))
                {
                    BuyerData.RemoveAt(i);
                    --i;
                }
            }
            Write();
        }

        // Сбор всех данных и запись.
        public void CreateInfo(TicketInfo ticket, Route need, RouteList roots)
        {
            var route = roots.Routes;
            var length = route.Count;

            BuyerData.Add(ticket);
            Write();

            for (var i = 0; i < length; ++i)
            {
                if (need.RouteNumber == route[i].RouteNumber)
                {
                    route[i].FreePlaces.Remove(ticket.Place);
                    roots.Write();
                }
            }
        }

        // Удаление ненужной информации из файла.
        public int DeleteInfo(int ticketNum, string name, string surname,
            string buyerId, RouteList routelist)
        {
            var place = 0;
            var routeCount = 0;
            var indTicket = -1;
            var stat = "Скасовано";

            foreach (var ticket in BuyerData)
            {
                if (ticketNum == ticket.TicketID && buyerId == ticket.BuyerID &&
                    name == ticket.Name && surname == ticket.Surname )
                {
                    indTicket = BuyerData.IndexOf(ticket);
                    routeCount = ticket.RouteNumber;
                    place = ticket.Place;
                    break;
                }
            }

            if (indTicket == -1)
            {
                return indTicket;
            }

            foreach (var add in routelist.Routes)
            {
                if (add.RouteNumber == routeCount &&
                    SearchStatus(BuyerData[indTicket]) != stat)
                {
                    add.FreePlaces.Add(place);
                    MainForm.MainTimetable.Write();
                    break;
                }
            }

            BuyerData.RemoveAt(indTicket);
            Write();

            return indTicket;
        }

        // Нахождения статуса билета.
        private string SearchStatus(TicketInfo data)
        {
            DateTime leaving = DateTime.Parse(data.LeavingTime);
            DateTime arriving = DateTime.Parse(data.ArrivingTime);
            DateTime now = DateTime.Now;
            bool exist = false;
            string result = "";
            var length = routeList.Routes.Count;

            for (var i = 0; i < length; ++i)
            {
                if (data.LeavingTime == routeList[i].LeavingTime &&
                    data.ArrivingTime == routeList[i].ArrivingTime &&
                    data.RouteNumber == routeList[i].RouteNumber)
                {
                    if (routeList[i].EndPointName != data.EndPointName)
                    {
                        for (var j = 0; j < routeList[i].GoThrough.Length; i++)
                        {
                            if (data.EndPointName == routeList[i].GoThrough[j].EndPointName)
                            {
                                exist = true;
                                break;
                            }
                        }
                    }
                    else
                    {
                        exist = true;
                        break;
                    }
                }
            }

            switch (exist)
            {
                case false:
                    result = "Скасовано";
                    break;

                case true:
                    if (now < leaving)
                    {
                        result = "Замовлено";
                    }
                    else if (now < arriving)
                    {
                        result = "У дорозі";
                    }
                    else
                    {
                        result = "Прибув";
                    }
                    break;
            }

            return result;
        }

        // Сортировка данных о покупателях.
        private void BuyersDataSort()
        {
            var length = BuyerData.Count;

            if (length == 0)
            {
                return;
            }

            SortBuyersByNumber();
            var amountRouts = BuyerData[0].RouteNumber;
            var amountBuyers = 0;
            var begin = 0;


            for (var i = 0; i < length; ++i)
            {
                if (amountRouts == BuyerData[i].RouteNumber)
                {
                    ++amountBuyers;
                }
                else
                {
                    SortBuyersByTicket(begin, amountBuyers);
                    begin = i;
                    amountBuyers = 0;
                    amountRouts = BuyerData[i].RouteNumber;
                }
            }
        }

        // Сортировка по номеру рейса.
        private void SortBuyersByNumber()
        {
            var length = BuyerData.Count;

            for (var i = length; i > 1; --i)
            {
                for (var j = 1; j < i; ++j)
                {
                    if (BuyerData[j - 1].RouteNumber > BuyerData[j].RouteNumber)
                    {
                        TicketInfo temp = BuyerData[j - 1];
                        BuyerData[j - 1] = BuyerData[j];
                        BuyerData[j] = temp;
                    }
                }
            }
        }

        // Сортировка по номеру билета покупателя.
        private void SortBuyersByTicket(int num, int length)
        {
            if (length == 1)
            {
                return;
            }

            for (var i = length; i > num + 1; --i)
            {
                for (var j = num + 1; j < i; ++j)
                {
                    if (BuyerData[j - 1].TicketID > BuyerData[j].TicketID)
                    {
                        TicketInfo temp = BuyerData[j];
                        BuyerData[j] = BuyerData[j - 1];
                        BuyerData[j - 1] = temp;
                    }
                }
            }
        }
    }
}
