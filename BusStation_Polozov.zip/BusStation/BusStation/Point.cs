﻿namespace BusStation
{
    // Класс конечной точки.
    public class Point
    {
        // Конструктор.
        public Point()
        {
            // Дефолтные значения.
            TicketPrice = 10;
            EndPointName = "Харків";
        }

        // Перегрузка конструктора.
        public Point(string name)
        {
            TicketPrice = 10;
            EndPointName = name;
        }

        // Перегрузка конструктора.
        public Point(string name, double price)
        {
            TicketPrice = price;
            EndPointName = name;
        }

        // Цена билета.
        public double TicketPrice { get; set; }

        // Название конечной точки.
        public string EndPointName { get; set; }
    }
}
