﻿using System.Text;
using System.IO;
using Newtonsoft.Json;

namespace BusStation
{
    // Класс проверки пароля.
    public static class Check
    {
        // Запись пароля в файл.
        public static void Write(string check)
        {
            File.WriteAllText("Check.json", JsonConvert.SerializeObject(check));
        }

        // Считывание пароля из файла.
        public static string Read()
        {
            string check = JsonConvert.DeserializeObject<string>
                (Encoding.UTF8.GetString(File.ReadAllBytes("Check.json")));

            // Если в документе отсутствует пароль.
            if (check == null)
            {
                check = "";     
            }

            return check;
        }
    }
}