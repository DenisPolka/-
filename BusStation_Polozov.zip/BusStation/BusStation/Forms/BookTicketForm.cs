﻿using System;
using System.Windows.Forms;
using System.ComponentModel;

namespace BusStation
{
    // Заказ билета.
    public partial class BookTicketForm : Form
    {
        private TicketInfo TicketInfo;

        // Конструктор.
        public BookTicketForm()
        {
            InitializeComponent();
        }

        // Форма.
        public static BookTicketForm Form { get; set; }

        // Нужный рейс.
        public BindingList<Route> ViewedRoute { get; set; }

        // Отобранное место.
        public string SelectedSeat
        {
            set { SeatTextBox.Text = value; }
        }

        private void BookTicketForm_Load(object sender, EventArgs e)
        {
            TicketInfo = new TicketInfo(ViewedRoute[0]);
            SumInfoLabel.Text = ViewedRoute[0].TicketPrice + " грн";
            RouteInfoDataGridView.DataSource = ViewedRoute;
        }

        private void NameTextBox_Leave(object sender, EventArgs e)
        {
            TicketInfo.Name = NameTextBox.Text;
        }

        private void SurnameTextBox_Leave(object sender, EventArgs e)
        {
            TicketInfo.Surname = SurnameTextBox.Text;
        }

        private void DocumentIDTextBox_Leave(object sender, EventArgs e)
        {
            TicketInfo.BuyerID = DocumentIDTextBox.Text;
        }

        private void ChooseSeatButton_Click(object sender, EventArgs e)
        {
            SeatChoiceForm.Form = new SeatChoiceForm();
            SeatChoiceForm.Form.FreePlaces = ViewedRoute[0].FreePlaces;
            SeatChoiceForm.Form.Show();
        }

        private void SeatTextBox_TextChanged(object sender, EventArgs e)
        {
            TicketInfo.Place = Int32.Parse(SeatTextBox.Text);
        }

        private void BookTicketButton_Click(object sender, EventArgs e)
        {
            if (NameTextBox.Text == "" || SurnameTextBox.Text == "" ||
                DocumentIDTextBox.Text == "" || SeatTextBox.Text == "")
            {
                MessageBox.Show(
                    "Одне чи декілька з обов'язкових полів є пустими.",
                    "Помилка",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

                return;
            }
            
            MainForm.Passengers.CreateInfo(
                TicketInfo, 
                ViewedRoute[0], 
                MainForm.MainTimetable);

            MessageBox.Show(
                    $"Квиток замовлено. Ваше місце: " +
                    $"{TicketInfo.Place}.\nУнікальний номер квитка: " +
                    $"{TicketInfo.TicketID}.\n" +
                    $"З його допомогою ви зможете повернути квиток.",
                    "Квиток замовлено",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

            RouteSelectionForm.Form.Close();

            if (PassengerListForm.Form != null)
            {
                PassengerListForm.Form.Refresh();
            }

            MainForm.Form.Refresh();
            Close();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            Close();
            RouteSelectionForm.Form.Show();
        }

        private void RouteInfoDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void NameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void PersonIDLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
