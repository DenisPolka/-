﻿namespace BusStation
{
    partial class TicketPricesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TicketPricesForm));
            this.PricesDataGridView = new System.Windows.Forms.DataGridView();
            this.destinationName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TicketPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pricesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.TicketPricesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.BackButton = new System.Windows.Forms.Button();
            this.TicketPricesLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.PricesDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pricesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TicketPricesBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // PricesDataGridView
            // 
            this.PricesDataGridView.AutoGenerateColumns = false;
            this.PricesDataGridView.BackgroundColor = System.Drawing.SystemColors.Control;
            this.PricesDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.PricesDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.PricesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.PricesDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.destinationName,
            this.TicketPrice});
            this.PricesDataGridView.DataSource = this.pricesBindingSource;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.PricesDataGridView.DefaultCellStyle = dataGridViewCellStyle2;
            this.PricesDataGridView.Location = new System.Drawing.Point(62, 77);
            this.PricesDataGridView.Name = "PricesDataGridView";
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PricesDataGridView.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.PricesDataGridView.Size = new System.Drawing.Size(340, 333);
            this.PricesDataGridView.TabIndex = 0;
            this.PricesDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.PricesDataGridView_CellContentClick_1);
            this.PricesDataGridView.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.PricesDataGridView_CellEndEdit);
            this.PricesDataGridView.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.PricesDataGridView_CellValidating);
            this.PricesDataGridView.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.PricesDataGridView_RowsRemoved);
            // 
            // destinationName
            // 
            this.destinationName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.destinationName.DataPropertyName = "EndPointName";
            this.destinationName.HeaderText = "Пункт призначення";
            this.destinationName.Name = "destinationName";
            this.destinationName.Width = 162;
            // 
            // TicketPrice
            // 
            this.TicketPrice.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.TicketPrice.DataPropertyName = "TicketPrice";
            this.TicketPrice.HeaderText = "Ціна білету, грн";
            this.TicketPrice.Name = "TicketPrice";
            this.TicketPrice.Width = 112;
            // 
            // pricesBindingSource
            // 
            this.pricesBindingSource.DataMember = "RoutePrices";
            this.pricesBindingSource.DataSource = this.TicketPricesBindingSource;
            // 
            // TicketPricesBindingSource
            // 
            this.TicketPricesBindingSource.DataSource = typeof(BusStation.TicketPrice);
            // 
            // BackButton
            // 
            this.BackButton.BackColor = System.Drawing.SystemColors.Control;
            this.BackButton.Font = new System.Drawing.Font("Cambria", 16F);
            this.BackButton.Location = new System.Drawing.Point(356, 428);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(118, 50);
            this.BackButton.TabIndex = 3;
            this.BackButton.Text = "Назад";
            this.BackButton.UseVisualStyleBackColor = false;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // TicketPricesLabel
            // 
            this.TicketPricesLabel.AutoSize = true;
            this.TicketPricesLabel.Font = new System.Drawing.Font("Cambria", 13.25F);
            this.TicketPricesLabel.Location = new System.Drawing.Point(24, 31);
            this.TicketPricesLabel.Name = "TicketPricesLabel";
            this.TicketPricesLabel.Size = new System.Drawing.Size(450, 21);
            this.TicketPricesLabel.TabIndex = 4;
            this.TicketPricesLabel.Text = "Введіть назву пункту призначення та ціну на квиток.\r\n";
            // 
            // TicketPricesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(498, 514);
            this.Controls.Add(this.TicketPricesLabel);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.PricesDataGridView);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "TicketPricesForm";
            this.Text = "Ціни на квитки";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.TicketPricesForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PricesDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pricesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TicketPricesBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView PricesDataGridView;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Label TicketPricesLabel;
        private System.Windows.Forms.BindingSource TicketPricesBindingSource;
        private System.Windows.Forms.BindingSource pricesBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn destinationName;
        private System.Windows.Forms.DataGridViewTextBoxColumn TicketPrice;
    }
}