﻿using System;
using System.Windows.Forms;
using System.ComponentModel;

namespace BusStation
{
    // Выбор рейса.
    public partial class RouteSelectionForm : Form
    {
        // Конструктор.
        public RouteSelectionForm()
        {
            InitializeComponent();
        }

        // Форма.
        public static RouteSelectionForm Form { get; set; }

        // Выбраный рейс.
        public Route SelectedRoute { get; set; }

        private void RouteSelectionForm_Load
            (object sender, EventArgs e)
        {
            SelectedRouteDataGridView.DataSource =
                MainForm.MainTimetable.SearchedData;
        }

        private void SelectedRouteDataGridView_SelectionChanged
            (object sender, EventArgs e)
        {
            if (SelectedRouteDataGridView.SelectedCells.Count > 0)
            {
                int selected =
                    SelectedRouteDataGridView.SelectedCells[0].RowIndex;

                SelectedRoute =
                    MainForm.MainTimetable.SearchedData[selected];
            }
        }

        private void BookTicketButton_Click(object sender, EventArgs e)
        {
            Hide();
            BookTicketForm.Form = new BookTicketForm();
            BookTicketForm.Form.ViewedRoute = new BindingList<Route>();
            BookTicketForm.Form.ViewedRoute.Add(SelectedRoute);
            BookTicketForm.Form.Show();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            Close();
            MainForm.Form.Show();
        }

        private void SelectedRouteDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
