﻿using System;
using System.Windows.Forms;

namespace BusStation
{
    // Форма для авторизации.
    public partial class AutorizationForm : Form
    {
        // Конструктор.
        public AutorizationForm()
        {

            InitializeComponent();
            if (MainForm.CurrentUser == 
                User.Admin)
            {
                AdminDisplay();
            }
            else
            {
                ClientDisplay();
            }
        }

        // Форма.
        public static AutorizationForm Form { get; set; }

        private void AdminDisplay()
        {
            EnterPassLabel.Visible = false;
            PasswordTextBox.Visible = false;
            EnterPassButton.Visible = false;
            AutorizedLabel.Visible = true;
        }

        private void ClientDisplay()
        {
            EnterPassLabel.Visible = true;
            PasswordTextBox.Visible = true;
            EnterPassButton.Visible = true;
            AutorizedLabel.Visible = false;
        }

        private void UnautorizedButton_Click
            (object sender, EventArgs e)
        {
            if (MainForm.CurrentUser == User.Admin)
            {
                ClientDisplay();
                MainForm.Form.SetClientAccess();

                if (PassengerListForm.Form != null)
                {
                    PassengerListForm.Form.Close();
                }

                if (PasswordChangeForm.Form != null)
                {
                    PasswordChangeForm.Form.Close();
                }

                if (TicketPricesForm.Form != null)
                {
                    TicketPricesForm.Form.Close();
                }
            }

            Close();
        }

        private void EnterPassButton_Click
            (object sender, EventArgs e)
        {
            if (PasswordTextBox.Text == 
                Check.Read())
            {
                if (MainForm.CurrentUser == 
                    User.Buyer)
                {
                    AdminDisplay();
                    MainForm.Form.SetAdminAccess();
                }

                Close();
            }
            else
            {
                MessageBox.Show(
                    "Невірний пароль.",
                    "Помилка",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void PasswordTextBox_KeyDown
            (object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                EnterPassButton_Click(null, null);
            }
        }

        private void BackButton_Click
            (object sender, EventArgs e)
        {
            Close();
        }

        private void AutorizationForm_Load(object sender, EventArgs e)
        {

        }

        private void AutorizedLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
