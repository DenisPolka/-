﻿using System;
using System.Windows.Forms;

namespace BusStation
{
    // Проверочный пароль.
    public partial class PasswordChangeForm : Form
    {
        // Конструктор.
        public PasswordChangeForm()
        {
            InitializeComponent();
        }

        // Смена пароля.
        public static PasswordChangeForm Form { get; set; }

        private void ConfirmPassButton_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                    "Змінити пароль?",
                    "Зміна паролю",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);

            if (result == DialogResult.No)
            {
                return;
            }

            string errorText = "";
            bool errorOccured = false;

            if (CurrentPassTextBox.Text == "" || 
                NewPassTextBox.Text == "" ||
                ConfirmPassTextBox.Text == "")
            {
                errorText = "Не всі поля заповнені.";
                errorOccured = true;
            }

            if (CurrentPassTextBox.Text != 
                Check.Read())
            {
                errorText = "Невірний поточний пароль.";
                errorOccured = true;
            }

            if (NewPassTextBox.Text !=
                ConfirmPassTextBox.Text)
            {
                errorText = "Паролі не співпадають.";
                errorOccured = true;
            }

            if (errorOccured)
            {
                MessageBox.Show(
                    errorText,
                    "Помилка",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }

            Check.Write(ConfirmPassTextBox.Text);
            MessageBox.Show(
                    "Пароль змінено.",
                    "Зміна паролю",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

            Close();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void PasswordChangeForm_Load(object sender, EventArgs e)
        {

        }

        private void NewPassTextBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
