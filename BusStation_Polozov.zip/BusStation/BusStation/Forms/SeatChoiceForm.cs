﻿using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace BusStation
{
    // Выбор места.
    public partial class SeatChoiceForm : Form
    {
        private string selectedSeat;

        // Конструктор.
        public SeatChoiceForm()
        {
            InitializeComponent();
        }

        // Форма.
        public static SeatChoiceForm Form { get; set; }

        // Список свободных мест.
        public BindingList<int> FreePlaces { get; set; }

        private void SeatChoiceForm_Load(object sender, EventArgs e)
        {
            SeatChoiceComboBox.DataSource = FreePlaces;
        }

        private void SeatChoiceComboBox_SelectedIndexChanged
            (object sender, EventArgs e)
        {
            selectedSeat = SeatChoiceComboBox.SelectedItem.ToString();
        }

        private void ConfirmButton_Click(object sender, EventArgs e)
        {
            BookTicketForm.Form.SelectedSeat = selectedSeat;
            Close();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BusScemePictureBox_Click(object sender, EventArgs e)
        {

        }
    }
}
