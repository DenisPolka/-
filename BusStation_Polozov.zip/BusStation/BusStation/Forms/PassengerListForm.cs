﻿using System;
using System.Windows.Forms;

namespace BusStation
{
    // Ведомость.
    public partial class PassengerListForm : Form
    {
        // Конструктор.
        public PassengerListForm()
        {
            InitializeComponent();
        }

        // Форма.
        public static PassengerListForm Form { get; set; }

        private void PassengerListForm_Load
            (object sender, EventArgs e)
        {
            MainForm.Passengers.Read();
            PassangerListDataGridView.DataSource = 
                MainForm.Passengers.BuyerData;
        }

        private void PassangerListDataGridView_CellValueChanged
            (object sender, DataGridViewCellEventArgs e)
        {
            MainForm.Passengers.Write();
        }

        private void deleteCancelledButton_Click
            (object sender, EventArgs e)
        {
            DialogResult delete = MessageBox.Show(
                "Ви точно хочете видалити скасовані?",
                "Видалити скасовані",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning,
                MessageBoxDefaultButton.Button1);

            if (delete == DialogResult.No)
            {
                return;
            }

            MainForm.Passengers.ClearWrong();

            MessageBox.Show(
                "Скасовані видалено.",
                "Видалити скасовані",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        private void BackButton_Click
            (object sender, EventArgs e)
        {
            Close();
        }

        private void PassangerListDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}