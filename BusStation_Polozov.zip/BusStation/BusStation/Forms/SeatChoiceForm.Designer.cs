﻿namespace BusStation
{
    partial class SeatChoiceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SeatChoiceForm));
            this.SeatChoiceComboBox = new System.Windows.Forms.ComboBox();
            this.seatsAvailableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.seatChoiceFormBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.SeatChoiceLlabel = new System.Windows.Forms.Label();
            this.BackButton = new System.Windows.Forms.Button();
            this.ConfirmButton = new System.Windows.Forms.Button();
            this.BusScemePictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.seatsAvailableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.seatChoiceFormBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BusScemePictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // SeatChoiceComboBox
            // 
            this.SeatChoiceComboBox.BackColor = System.Drawing.SystemColors.Window;
            this.SeatChoiceComboBox.DataSource = this.seatsAvailableBindingSource;
            this.SeatChoiceComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SeatChoiceComboBox.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SeatChoiceComboBox.FormattingEnabled = true;
            this.SeatChoiceComboBox.Location = new System.Drawing.Point(249, 467);
            this.SeatChoiceComboBox.Name = "SeatChoiceComboBox";
            this.SeatChoiceComboBox.Size = new System.Drawing.Size(63, 30);
            this.SeatChoiceComboBox.TabIndex = 0;
            this.SeatChoiceComboBox.SelectedIndexChanged += new System.EventHandler(this.SeatChoiceComboBox_SelectedIndexChanged);
            // 
            // seatsAvailableBindingSource
            // 
            this.seatsAvailableBindingSource.DataMember = "FreePlaces";
            this.seatsAvailableBindingSource.DataSource = this.seatChoiceFormBindingSource;
            // 
            // seatChoiceFormBindingSource
            // 
            this.seatChoiceFormBindingSource.DataSource = typeof(BusStation.SeatChoiceForm);
            // 
            // SeatChoiceLlabel
            // 
            this.SeatChoiceLlabel.AutoSize = true;
            this.SeatChoiceLlabel.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SeatChoiceLlabel.Location = new System.Drawing.Point(87, 470);
            this.SeatChoiceLlabel.Name = "SeatChoiceLlabel";
            this.SeatChoiceLlabel.Size = new System.Drawing.Size(143, 22);
            this.SeatChoiceLlabel.TabIndex = 1;
            this.SeatChoiceLlabel.Text = "Виберіть місце:";
            // 
            // BackButton
            // 
            this.BackButton.BackColor = System.Drawing.SystemColors.Control;
            this.BackButton.Font = new System.Drawing.Font("Cambria", 16F);
            this.BackButton.Location = new System.Drawing.Point(47, 517);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(111, 42);
            this.BackButton.TabIndex = 16;
            this.BackButton.Text = "Назад";
            this.BackButton.UseVisualStyleBackColor = false;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // ConfirmButton
            // 
            this.ConfirmButton.BackColor = System.Drawing.SystemColors.Control;
            this.ConfirmButton.Font = new System.Drawing.Font("Cambria", 16F);
            this.ConfirmButton.Location = new System.Drawing.Point(199, 517);
            this.ConfirmButton.Name = "ConfirmButton";
            this.ConfirmButton.Size = new System.Drawing.Size(166, 42);
            this.ConfirmButton.TabIndex = 15;
            this.ConfirmButton.Text = "Підтвердити";
            this.ConfirmButton.UseVisualStyleBackColor = false;
            this.ConfirmButton.Click += new System.EventHandler(this.ConfirmButton_Click);
            // 
            // BusScemePictureBox
            // 
            this.BusScemePictureBox.Image = global::BusStation.Properties.Resources.xbp_4207_xbuvlyi;
            this.BusScemePictureBox.Location = new System.Drawing.Point(47, 28);
            this.BusScemePictureBox.Name = "BusScemePictureBox";
            this.BusScemePictureBox.Size = new System.Drawing.Size(318, 414);
            this.BusScemePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.BusScemePictureBox.TabIndex = 17;
            this.BusScemePictureBox.TabStop = false;
            this.BusScemePictureBox.Click += new System.EventHandler(this.BusScemePictureBox_Click);
            // 
            // SeatChoiceForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(416, 596);
            this.Controls.Add(this.BusScemePictureBox);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.ConfirmButton);
            this.Controls.Add(this.SeatChoiceLlabel);
            this.Controls.Add(this.SeatChoiceComboBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SeatChoiceForm";
            this.Text = "Вибір місця";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.SeatChoiceForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.seatsAvailableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.seatChoiceFormBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BusScemePictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox SeatChoiceComboBox;
        private System.Windows.Forms.BindingSource seatChoiceFormBindingSource;
        private System.Windows.Forms.BindingSource seatsAvailableBindingSource;
        private System.Windows.Forms.Label SeatChoiceLlabel;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Button ConfirmButton;
        private System.Windows.Forms.PictureBox BusScemePictureBox;
    }
}