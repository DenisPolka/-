﻿namespace BusStation
{
    partial class BookTicketForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BookTicketForm));
            this.HeaderLabel = new System.Windows.Forms.Label();
            this.NameLabel = new System.Windows.Forms.Label();
            this.SurnameLabel = new System.Windows.Forms.Label();
            this.PersonIDLabel = new System.Windows.Forms.Label();
            this.SumLabel = new System.Windows.Forms.Label();
            this.BookTicketButton = new System.Windows.Forms.Button();
            this.SumInfoLabel = new System.Windows.Forms.Label();
            this.NameTextBox = new System.Windows.Forms.TextBox();
            this.SurnameTextBox = new System.Windows.Forms.TextBox();
            this.DocumentIDTextBox = new System.Windows.Forms.TextBox();
            this.BackButton = new System.Windows.Forms.Button();
            this.RouteInfoDataGridView = new System.Windows.Forms.DataGridView();
            this.routeNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.destinationNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.departureDateTimeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.arrivalDateTimeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TicketsAvailableDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TicketPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.viewedRouteBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bookTicketFormBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.SeatLabel = new System.Windows.Forms.Label();
            this.ChooseSeatButton = new System.Windows.Forms.Button();
            this.SeatTextBox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.RouteInfoDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewedRouteBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookTicketFormBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // HeaderLabel
            // 
            this.HeaderLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.HeaderLabel.AutoSize = true;
            this.HeaderLabel.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.HeaderLabel.Location = new System.Drawing.Point(294, 16);
            this.HeaderLabel.Name = "HeaderLabel";
            this.HeaderLabel.Size = new System.Drawing.Size(227, 28);
            this.HeaderLabel.TabIndex = 0;
            this.HeaderLabel.Text = "Замовлення квитка";
            // 
            // NameLabel
            // 
            this.NameLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.NameLabel.AutoSize = true;
            this.NameLabel.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NameLabel.Location = new System.Drawing.Point(26, 209);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(44, 22);
            this.NameLabel.TabIndex = 1;
            this.NameLabel.Text = "Ім\'я";
            // 
            // SurnameLabel
            // 
            this.SurnameLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SurnameLabel.AutoSize = true;
            this.SurnameLabel.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SurnameLabel.Location = new System.Drawing.Point(26, 267);
            this.SurnameLabel.Name = "SurnameLabel";
            this.SurnameLabel.Size = new System.Drawing.Size(93, 22);
            this.SurnameLabel.TabIndex = 2;
            this.SurnameLabel.Text = "Прізвище";
            // 
            // PersonIDLabel
            // 
            this.PersonIDLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PersonIDLabel.AutoSize = true;
            this.PersonIDLabel.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PersonIDLabel.Location = new System.Drawing.Point(27, 324);
            this.PersonIDLabel.Name = "PersonIDLabel";
            this.PersonIDLabel.Size = new System.Drawing.Size(103, 44);
            this.PersonIDLabel.TabIndex = 3;
            this.PersonIDLabel.Text = "Номер \r\nдокумента";
            this.PersonIDLabel.Click += new System.EventHandler(this.PersonIDLabel_Click);
            // 
            // SumLabel
            // 
            this.SumLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SumLabel.AutoSize = true;
            this.SumLabel.Font = new System.Drawing.Font("Cambria", 16.25F);
            this.SumLabel.Location = new System.Drawing.Point(501, 389);
            this.SumLabel.Name = "SumLabel";
            this.SumLabel.Size = new System.Drawing.Size(63, 26);
            this.SumLabel.TabIndex = 5;
            this.SumLabel.Text = "Ціна:";
            // 
            // BookTicketButton
            // 
            this.BookTicketButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.BookTicketButton.BackColor = System.Drawing.SystemColors.Control;
            this.BookTicketButton.Font = new System.Drawing.Font("Cambria", 16F);
            this.BookTicketButton.Location = new System.Drawing.Point(412, 476);
            this.BookTicketButton.Name = "BookTicketButton";
            this.BookTicketButton.Size = new System.Drawing.Size(157, 43);
            this.BookTicketButton.TabIndex = 7;
            this.BookTicketButton.Text = "Замовити";
            this.BookTicketButton.UseVisualStyleBackColor = false;
            this.BookTicketButton.Click += new System.EventHandler(this.BookTicketButton_Click);
            // 
            // SumInfoLabel
            // 
            this.SumInfoLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SumInfoLabel.AutoSize = true;
            this.SumInfoLabel.Font = new System.Drawing.Font("Cambria", 16.25F);
            this.SumInfoLabel.Location = new System.Drawing.Point(565, 389);
            this.SumInfoLabel.Name = "SumInfoLabel";
            this.SumInfoLabel.Size = new System.Drawing.Size(127, 26);
            this.SumInfoLabel.TabIndex = 9;
            this.SumInfoLabel.Text = "інформація";
            // 
            // NameTextBox
            // 
            this.NameTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.NameTextBox.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NameTextBox.Location = new System.Drawing.Point(188, 206);
            this.NameTextBox.Name = "NameTextBox";
            this.NameTextBox.Size = new System.Drawing.Size(607, 30);
            this.NameTextBox.TabIndex = 10;
            this.NameTextBox.TextChanged += new System.EventHandler(this.NameTextBox_TextChanged);
            this.NameTextBox.Leave += new System.EventHandler(this.NameTextBox_Leave);
            // 
            // SurnameTextBox
            // 
            this.SurnameTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SurnameTextBox.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SurnameTextBox.Location = new System.Drawing.Point(188, 264);
            this.SurnameTextBox.Name = "SurnameTextBox";
            this.SurnameTextBox.Size = new System.Drawing.Size(607, 30);
            this.SurnameTextBox.TabIndex = 11;
            this.SurnameTextBox.Leave += new System.EventHandler(this.SurnameTextBox_Leave);
            // 
            // DocumentIDTextBox
            // 
            this.DocumentIDTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.DocumentIDTextBox.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.DocumentIDTextBox.Location = new System.Drawing.Point(188, 321);
            this.DocumentIDTextBox.Name = "DocumentIDTextBox";
            this.DocumentIDTextBox.Size = new System.Drawing.Size(607, 30);
            this.DocumentIDTextBox.TabIndex = 12;
            this.DocumentIDTextBox.Leave += new System.EventHandler(this.DocumentIDTextBox_Leave);
            // 
            // BackButton
            // 
            this.BackButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.BackButton.BackColor = System.Drawing.SystemColors.Control;
            this.BackButton.Font = new System.Drawing.Font("Cambria", 16F);
            this.BackButton.Location = new System.Drawing.Point(246, 476);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(114, 43);
            this.BackButton.TabIndex = 14;
            this.BackButton.Text = "Назад";
            this.BackButton.UseVisualStyleBackColor = false;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // RouteInfoDataGridView
            // 
            this.RouteInfoDataGridView.AllowUserToAddRows = false;
            this.RouteInfoDataGridView.AllowUserToDeleteRows = false;
            this.RouteInfoDataGridView.AllowUserToResizeColumns = false;
            this.RouteInfoDataGridView.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.RouteInfoDataGridView.AutoGenerateColumns = false;
            this.RouteInfoDataGridView.BackgroundColor = System.Drawing.SystemColors.Control;
            this.RouteInfoDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.RouteInfoDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.RouteInfoDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.RouteInfoDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.routeNumberDataGridViewTextBoxColumn,
            this.destinationNameDataGridViewTextBoxColumn,
            this.departureDateTimeDataGridViewTextBoxColumn,
            this.arrivalDateTimeDataGridViewTextBoxColumn,
            this.TicketsAvailableDataGridViewTextBoxColumn,
            this.TicketPriceDataGridViewTextBoxColumn});
            this.RouteInfoDataGridView.DataSource = this.viewedRouteBindingSource;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.RouteInfoDataGridView.DefaultCellStyle = dataGridViewCellStyle2;
            this.RouteInfoDataGridView.Location = new System.Drawing.Point(24, 70);
            this.RouteInfoDataGridView.Name = "RouteInfoDataGridView";
            this.RouteInfoDataGridView.ReadOnly = true;
            this.RouteInfoDataGridView.Size = new System.Drawing.Size(785, 91);
            this.RouteInfoDataGridView.TabIndex = 15;
            // 
            // routeNumberDataGridViewTextBoxColumn
            // 
            this.routeNumberDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.routeNumberDataGridViewTextBoxColumn.DataPropertyName = "RouteNumber";
            this.routeNumberDataGridViewTextBoxColumn.HeaderText = "Рейс";
            this.routeNumberDataGridViewTextBoxColumn.Name = "routeNumberDataGridViewTextBoxColumn";
            this.routeNumberDataGridViewTextBoxColumn.ReadOnly = true;
            this.routeNumberDataGridViewTextBoxColumn.Width = 67;
            // 
            // destinationNameDataGridViewTextBoxColumn
            // 
            this.destinationNameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.destinationNameDataGridViewTextBoxColumn.DataPropertyName = "EndPointName";
            this.destinationNameDataGridViewTextBoxColumn.HeaderText = "Пункт призначення";
            this.destinationNameDataGridViewTextBoxColumn.Name = "destinationNameDataGridViewTextBoxColumn";
            this.destinationNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.destinationNameDataGridViewTextBoxColumn.Width = 162;
            // 
            // departureDateTimeDataGridViewTextBoxColumn
            // 
            this.departureDateTimeDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.departureDateTimeDataGridViewTextBoxColumn.DataPropertyName = "LeavingTime";
            this.departureDateTimeDataGridViewTextBoxColumn.HeaderText = "Пункт прибуття";
            this.departureDateTimeDataGridViewTextBoxColumn.Name = "departureDateTimeDataGridViewTextBoxColumn";
            this.departureDateTimeDataGridViewTextBoxColumn.ReadOnly = true;
            this.departureDateTimeDataGridViewTextBoxColumn.Width = 139;
            // 
            // arrivalDateTimeDataGridViewTextBoxColumn
            // 
            this.arrivalDateTimeDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.arrivalDateTimeDataGridViewTextBoxColumn.DataPropertyName = "ArrivingTime";
            this.arrivalDateTimeDataGridViewTextBoxColumn.HeaderText = "Пункт призначення";
            this.arrivalDateTimeDataGridViewTextBoxColumn.Name = "arrivalDateTimeDataGridViewTextBoxColumn";
            this.arrivalDateTimeDataGridViewTextBoxColumn.ReadOnly = true;
            this.arrivalDateTimeDataGridViewTextBoxColumn.Width = 162;
            // 
            // TicketsAvailableDataGridViewTextBoxColumn
            // 
            this.TicketsAvailableDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.TicketsAvailableDataGridViewTextBoxColumn.DataPropertyName = "TicketsFree";
            this.TicketsAvailableDataGridViewTextBoxColumn.HeaderText = "Вільні місця";
            this.TicketsAvailableDataGridViewTextBoxColumn.Name = "TicketsAvailableDataGridViewTextBoxColumn";
            this.TicketsAvailableDataGridViewTextBoxColumn.ReadOnly = true;
            this.TicketsAvailableDataGridViewTextBoxColumn.Width = 112;
            // 
            // TicketPriceDataGridViewTextBoxColumn
            // 
            this.TicketPriceDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.TicketPriceDataGridViewTextBoxColumn.DataPropertyName = "TicketPrice";
            this.TicketPriceDataGridViewTextBoxColumn.HeaderText = "Ціна, грн";
            this.TicketPriceDataGridViewTextBoxColumn.Name = "TicketPriceDataGridViewTextBoxColumn";
            this.TicketPriceDataGridViewTextBoxColumn.ReadOnly = true;
            this.TicketPriceDataGridViewTextBoxColumn.Width = 90;
            // 
            // viewedRouteBindingSource
            // 
            this.viewedRouteBindingSource.DataMember = "ViewedRoute";
            this.viewedRouteBindingSource.DataSource = this.bookTicketFormBindingSource;
            // 
            // bookTicketFormBindingSource
            // 
            this.bookTicketFormBindingSource.DataSource = typeof(BusStation.BookTicketForm);
            // 
            // SeatLabel
            // 
            this.SeatLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SeatLabel.AutoSize = true;
            this.SeatLabel.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SeatLabel.Location = new System.Drawing.Point(27, 397);
            this.SeatLabel.Name = "SeatLabel";
            this.SeatLabel.Size = new System.Drawing.Size(59, 22);
            this.SeatLabel.TabIndex = 16;
            this.SeatLabel.Text = "Місце";
            // 
            // ChooseSeatButton
            // 
            this.ChooseSeatButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ChooseSeatButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ChooseSeatButton.BackColor = System.Drawing.SystemColors.Control;
            this.ChooseSeatButton.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ChooseSeatButton.Location = new System.Drawing.Point(357, 389);
            this.ChooseSeatButton.Name = "ChooseSeatButton";
            this.ChooseSeatButton.Size = new System.Drawing.Size(97, 30);
            this.ChooseSeatButton.TabIndex = 17;
            this.ChooseSeatButton.Text = "Вибрати";
            this.ChooseSeatButton.UseVisualStyleBackColor = false;
            this.ChooseSeatButton.Click += new System.EventHandler(this.ChooseSeatButton_Click);
            // 
            // SeatTextBox
            // 
            this.SeatTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SeatTextBox.BackColor = System.Drawing.SystemColors.Window;
            this.SeatTextBox.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SeatTextBox.Location = new System.Drawing.Point(188, 389);
            this.SeatTextBox.Name = "SeatTextBox";
            this.SeatTextBox.ReadOnly = true;
            this.SeatTextBox.Size = new System.Drawing.Size(151, 30);
            this.SeatTextBox.TabIndex = 18;
            this.SeatTextBox.TextChanged += new System.EventHandler(this.SeatTextBox_TextChanged);
            // 
            // BookTicketForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(824, 541);
            this.Controls.Add(this.SeatTextBox);
            this.Controls.Add(this.ChooseSeatButton);
            this.Controls.Add(this.SeatLabel);
            this.Controls.Add(this.RouteInfoDataGridView);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.DocumentIDTextBox);
            this.Controls.Add(this.SurnameTextBox);
            this.Controls.Add(this.NameTextBox);
            this.Controls.Add(this.SumInfoLabel);
            this.Controls.Add(this.BookTicketButton);
            this.Controls.Add(this.SumLabel);
            this.Controls.Add(this.PersonIDLabel);
            this.Controls.Add(this.SurnameLabel);
            this.Controls.Add(this.NameLabel);
            this.Controls.Add(this.HeaderLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimumSize = new System.Drawing.Size(840, 580);
            this.Name = "BookTicketForm";
            this.Text = "Замовлення квитка";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.BookTicketForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.RouteInfoDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewedRouteBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookTicketFormBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label HeaderLabel;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Label SurnameLabel;
        private System.Windows.Forms.Label PersonIDLabel;
        private System.Windows.Forms.Label SumLabel;
        private System.Windows.Forms.Button BookTicketButton;
        private System.Windows.Forms.Label SumInfoLabel;
        private System.Windows.Forms.TextBox NameTextBox;
        private System.Windows.Forms.TextBox SurnameTextBox;
        private System.Windows.Forms.TextBox DocumentIDTextBox;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.DataGridView RouteInfoDataGridView;
        private System.Windows.Forms.BindingSource bookTicketFormBindingSource;
        private System.Windows.Forms.Label SeatLabel;
        private System.Windows.Forms.Button ChooseSeatButton;
        private System.Windows.Forms.TextBox SeatTextBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn routeNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn destinationNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn departureDateTimeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn arrivalDateTimeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn TicketsAvailableDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn TicketPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource viewedRouteBindingSource;
    }
}