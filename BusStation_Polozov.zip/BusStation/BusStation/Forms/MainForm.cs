﻿using System;
using System.Windows.Forms;

namespace BusStation
{
    // Главная страница.
    public partial class MainForm : Form
    {
        // Конструктор.
        public MainForm()
        {
            MainTimetable = new RouteList();
            PriceList = new TicketPrice();
            Passengers = new BuyerList(MainTimetable);

            InitializeComponent();
        }

        // Главная форма.
        public static MainForm Form { get; set; }

        // Расписание.
        public static RouteList MainTimetable { get; set; }

        // Ведомость.
        public static BuyerList Passengers { get; set; }

        // Цены на билеты.
        public static TicketPrice PriceList { get; set; }

        // Текущий пользователь.
        public static User CurrentUser { get; set; }

        // Доступ функций для диспетчера.
        public void SetAdminAccess()
        {
            CurrentUser = User.Admin;
            Text = "Каса автовокзалу - диспетчер";
            TimetableDataGridView.ReadOnly = false;
            TimetableDataGridView.Columns[5].ReadOnly = true;
            TimetableDataGridView.AllowUserToAddRows = true;
            TimetableDataGridView.AllowUserToDeleteRows = true;
            AdminMenuStrip.Visible = true;
        }

        // Доступ функций для покупателя.
        public void SetClientAccess()
        {
            CurrentUser = User.Buyer;
            Text = "Каса автовокзалу - клієнт";
            TimetableDataGridView.ReadOnly = true;
            TimetableDataGridView.AllowUserToAddRows = false;
            TimetableDataGridView.AllowUserToDeleteRows = false;
            AdminMenuStrip.Visible = false;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            TimetableDataGridView.DataSource = 
                MainTimetable.Routes;
            SetClientAccess();
        }
        
        private void TimetableDataGridView_CellValidating
            (object sender, DataGridViewCellValidatingEventArgs e)
        {
            string columnName = 
                TimetableDataGridView.Columns[e.ColumnIndex].Name;
            string value = e.FormattedValue.ToString();

            switch (columnName)
            {
                case "destination":
                    if (String.IsNullOrEmpty(value))
                    {
                        TimetableDataGridView.Rows[e.RowIndex].ErrorText =
                            "Порожня назва пункту призначення.";
                        e.Cancel = true;
                    }
                    break;

                case "departureDateTime":
                case "arrivalDateTime":
                    DateTime thisDate;
                    DateTime otherDate;
                    int compareDates = 1;
                    string dateErrorText =
                        "Дата відправлення дорівнює або " +
                        "є пізніше дати прибуття.";
                    if (columnName == "arrivalDateTime")
                    {
                        dateErrorText =
                            "Дата прибуття дорівнює або " +
                            "є раніше дати відправлення.";
                        compareDates = -1;
                    }

                    try
                    {
                        thisDate = DateTime.Parse(value);

                        otherDate = DateTime.Parse(TimetableDataGridView.Rows
                            [e.RowIndex].Cells[e.ColumnIndex + compareDates]
                            .Value.ToString());

                        if (thisDate.CompareTo(otherDate) * compareDates >= 0)
                        {
                            throw new Exception(dateErrorText);
                        }
                    }
                    catch (FormatException)
                    {
                        TimetableDataGridView.Rows[e.RowIndex].ErrorText =
                            "Невірний формат дати та часу.";
                        e.Cancel = true;
                    }
                    catch (Exception)
                    {
                        TimetableDataGridView.Rows[e.RowIndex].ErrorText =
                            dateErrorText;
                        e.Cancel = true;
                    }
                    break;

                case "routeNumber":
                    try
                    {
                        if (Int32.Parse(value) <= 0)
                        {
                            throw new FormatException();
                        }
                    }
                    catch (FormatException)
                    {
                        TimetableDataGridView.Rows[e.RowIndex].ErrorText =
                            "Номер рейсу не є натуральним числом.";
                        e.Cancel = true;
                    }
                    catch (OverflowException)
                    {
                        TimetableDataGridView.Rows[e.RowIndex].ErrorText =
                            "Число є дуже великим.";
                        e.Cancel = true;
                    }
                    catch (ArgumentNullException)
                    {
                        TimetableDataGridView.Rows[e.RowIndex].ErrorText =
                            "Ви не ввели нічого.";
                        e.Cancel = true;
                    }
                    break;
            }

            if (e.Cancel)
            {
                MessageBox.Show(
                    TimetableDataGridView.Rows[e.RowIndex].ErrorText +
                    "\nДля відміни натисніть ESC.",
                    "Помилка",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void TimetableDataGridView_CellEndEdit
            (object sender, DataGridViewCellEventArgs e)
        {
            TimetableDataGridView.Rows[e.RowIndex].ErrorText = "";

            if (TimetableDataGridView.Rows
                    [e.RowIndex].Cells[0].Value == null)
            {
                return;
            }

            for (int i = 0; i < MainTimetable.Routes.Count; i++)
            {
                if (MainTimetable[i].RouteNumber.ToString() ==
                    TimetableDataGridView.Rows
                    [e.RowIndex].Cells[0].Value.ToString())
                {
                    MainTimetable[i].CreatePlaces();
                }
            }
            MainTimetable.Write();

            if (PassengerListForm.Form != null)
            {
                PassengerListForm.Form.Refresh();
            }
        }

        private void TimetableDataGridView_RowsRemoved
            (object sender, DataGridViewRowsRemovedEventArgs e)
        {
            MainTimetable.Write();
        }

        private void SearchRouteButton_Click(object sender, EventArgs e)
        {
            string userDestination = InputDestTextBox.Text;

            if (userDestination == "")
            {
                return;
            }

            MainTimetable.RoutesByEndPoint
                (userDestination, PriceList);

            if (MainTimetable.SearchedData.Count == 0)
            {
                MessageBox.Show(
                    "Маршруту з заданим пунктом не знайдено " +
                    "або усі автобуси уже відбули.",
                    "Помилка",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            else
            {
                RouteSelectionForm.Form = new RouteSelectionForm();
                RouteSelectionForm.Form.Show();
            }
        }

        private void InputDestTextBox_KeyDown
            (object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                SearchRouteButton_Click(null, null);
            }
        }

        private void ReturnTicketButton_Click
            (object sender, EventArgs e)
        {
            ReturnTicketForm.Form = new ReturnTicketForm();
            ReturnTicketForm.Form.Show();
        }

        private void OpenPassListToolStripMenuItem_Click
            (object sender, EventArgs e)
        {
            PassengerListForm.Form = new PassengerListForm();
            PassengerListForm.Form.Show();
        }

        private void OpenPricesToolStripMenuItem1_Click
            (object sender, EventArgs e)
        {
            TicketPricesForm.Form = new TicketPricesForm();
            TicketPricesForm.Form.Show();
        }

        private void AutorizationButton_Click
            (object sender, EventArgs e)
        {
            AutorizationForm.Form = new AutorizationForm();
            AutorizationForm.Form.Show();
        }

        private void ChangePassToolStripMenuItem_Click
            (object sender, EventArgs e)
        {
            PasswordChangeForm.Form = new PasswordChangeForm();
            PasswordChangeForm.Form.Show();
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void TimetableDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
