﻿using System;
using System.Windows.Forms;

namespace BusStation
{
    // Возврат билета.
    public partial class ReturnTicketForm : Form
    {
        // Конструктор.
        public ReturnTicketForm()
        {
            InitializeComponent();
        }

        // Форма.
        public static ReturnTicketForm Form { get; set; }

        private void BackButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void ReturnTicketButton_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Ви впевнені, що хочете повернути квиток?",
                "Повернення квитка",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning,
                MessageBoxDefaultButton.Button1);

            if (result == DialogResult.No)
            {
                return;
            }

            string name = NameTextBox.Text;
            string surname = SurnameTextBox.Text;
            string documentID = DocumentIDTextBox.Text;
            string TicketID = TicketIDTextBox.Text;
            int TicketIndex;

            if (name == "" || surname == "" ||
                documentID == "" || TicketID == "")
            {
                MessageBox.Show(
                    "Одне чи декілька з обов'язкових полів є пустими.",
                    "Помилка",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }

            TicketIndex = MainForm.Passengers.DeleteInfo(
                Int32.Parse(TicketID),
                name,
                surname,
                documentID,
                MainForm.MainTimetable);

            if (TicketIndex == -1)
            {
                MessageBox.Show(
                    "Квитка з заданими даними не знайдено.",
                    "Помилка",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }

            MessageBox.Show(
                $"Квиток {TicketID} повернено.",
                "Повернення квитка",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);

            if (PassengerListForm.Form != null)
            {
                PassengerListForm.Form.Refresh();
            }

            MainForm.Form.Refresh();
            Close();
        }

        private void SurnameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void ReturnTicketForm_Load(object sender, EventArgs e)
        {

        }
    }
}
