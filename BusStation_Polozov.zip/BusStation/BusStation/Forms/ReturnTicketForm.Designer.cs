﻿namespace BusStation
{
    partial class ReturnTicketForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ReturnTicketForm));
            this.HeaderLabel = new System.Windows.Forms.Label();
            this.DocumentIDTextBox = new System.Windows.Forms.TextBox();
            this.SurnameTextBox = new System.Windows.Forms.TextBox();
            this.NameTextBox = new System.Windows.Forms.TextBox();
            this.PersonIDLabel = new System.Windows.Forms.Label();
            this.SurnameLabel = new System.Windows.Forms.Label();
            this.NameLabel = new System.Windows.Forms.Label();
            this.BackButton = new System.Windows.Forms.Button();
            this.ReturnTicketButton = new System.Windows.Forms.Button();
            this.TicketIDLabel = new System.Windows.Forms.Label();
            this.TicketIDTextBox = new System.Windows.Forms.MaskedTextBox();
            this.SuspendLayout();
            // 
            // HeaderLabel
            // 
            this.HeaderLabel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.HeaderLabel.AutoSize = true;
            this.HeaderLabel.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.HeaderLabel.Location = new System.Drawing.Point(209, 19);
            this.HeaderLabel.Name = "HeaderLabel";
            this.HeaderLabel.Size = new System.Drawing.Size(228, 28);
            this.HeaderLabel.TabIndex = 0;
            this.HeaderLabel.Text = "Повернення квитка";
            // 
            // DocumentIDTextBox
            // 
            this.DocumentIDTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.DocumentIDTextBox.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.DocumentIDTextBox.Location = new System.Drawing.Point(199, 185);
            this.DocumentIDTextBox.Name = "DocumentIDTextBox";
            this.DocumentIDTextBox.Size = new System.Drawing.Size(405, 30);
            this.DocumentIDTextBox.TabIndex = 19;
            // 
            // SurnameTextBox
            // 
            this.SurnameTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SurnameTextBox.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SurnameTextBox.Location = new System.Drawing.Point(199, 128);
            this.SurnameTextBox.Name = "SurnameTextBox";
            this.SurnameTextBox.Size = new System.Drawing.Size(405, 30);
            this.SurnameTextBox.TabIndex = 18;
            this.SurnameTextBox.TextChanged += new System.EventHandler(this.SurnameTextBox_TextChanged);
            // 
            // NameTextBox
            // 
            this.NameTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.NameTextBox.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NameTextBox.Location = new System.Drawing.Point(199, 70);
            this.NameTextBox.Name = "NameTextBox";
            this.NameTextBox.Size = new System.Drawing.Size(405, 30);
            this.NameTextBox.TabIndex = 17;
            // 
            // PersonIDLabel
            // 
            this.PersonIDLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PersonIDLabel.AutoSize = true;
            this.PersonIDLabel.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PersonIDLabel.Location = new System.Drawing.Point(38, 188);
            this.PersonIDLabel.Name = "PersonIDLabel";
            this.PersonIDLabel.Size = new System.Drawing.Size(136, 44);
            this.PersonIDLabel.TabIndex = 16;
            this.PersonIDLabel.Text = "Номер та серія\r\nдокумента";
            // 
            // SurnameLabel
            // 
            this.SurnameLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.SurnameLabel.AutoSize = true;
            this.SurnameLabel.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SurnameLabel.Location = new System.Drawing.Point(37, 131);
            this.SurnameLabel.Name = "SurnameLabel";
            this.SurnameLabel.Size = new System.Drawing.Size(93, 22);
            this.SurnameLabel.TabIndex = 15;
            this.SurnameLabel.Text = "Прізвище";
            // 
            // NameLabel
            // 
            this.NameLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.NameLabel.AutoSize = true;
            this.NameLabel.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NameLabel.Location = new System.Drawing.Point(37, 73);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(44, 22);
            this.NameLabel.TabIndex = 14;
            this.NameLabel.Text = "Ім\'я";
            // 
            // BackButton
            // 
            this.BackButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.BackButton.BackColor = System.Drawing.SystemColors.Control;
            this.BackButton.Font = new System.Drawing.Font("Cambria", 16F);
            this.BackButton.Location = new System.Drawing.Point(283, 314);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(116, 36);
            this.BackButton.TabIndex = 29;
            this.BackButton.Text = "Назад";
            this.BackButton.UseVisualStyleBackColor = false;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // ReturnTicketButton
            // 
            this.ReturnTicketButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.ReturnTicketButton.BackColor = System.Drawing.SystemColors.Control;
            this.ReturnTicketButton.Font = new System.Drawing.Font("Cambria", 16F);
            this.ReturnTicketButton.Location = new System.Drawing.Point(451, 314);
            this.ReturnTicketButton.Name = "ReturnTicketButton";
            this.ReturnTicketButton.Size = new System.Drawing.Size(153, 36);
            this.ReturnTicketButton.TabIndex = 28;
            this.ReturnTicketButton.Text = "Повернути";
            this.ReturnTicketButton.UseVisualStyleBackColor = false;
            this.ReturnTicketButton.Click += new System.EventHandler(this.ReturnTicketButton_Click);
            // 
            // TicketIDLabel
            // 
            this.TicketIDLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.TicketIDLabel.AutoSize = true;
            this.TicketIDLabel.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TicketIDLabel.Location = new System.Drawing.Point(37, 257);
            this.TicketIDLabel.Name = "TicketIDLabel";
            this.TicketIDLabel.Size = new System.Drawing.Size(130, 22);
            this.TicketIDLabel.TabIndex = 30;
            this.TicketIDLabel.Text = "Номер квитка";
            // 
            // TicketIDTextBox
            // 
            this.TicketIDTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.TicketIDTextBox.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TicketIDTextBox.Location = new System.Drawing.Point(199, 249);
            this.TicketIDTextBox.Mask = "00000000";
            this.TicketIDTextBox.Name = "TicketIDTextBox";
            this.TicketIDTextBox.Size = new System.Drawing.Size(405, 30);
            this.TicketIDTextBox.TabIndex = 31;
            // 
            // ReturnTicketForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(664, 381);
            this.Controls.Add(this.TicketIDTextBox);
            this.Controls.Add(this.TicketIDLabel);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.ReturnTicketButton);
            this.Controls.Add(this.DocumentIDTextBox);
            this.Controls.Add(this.SurnameTextBox);
            this.Controls.Add(this.NameTextBox);
            this.Controls.Add(this.PersonIDLabel);
            this.Controls.Add(this.SurnameLabel);
            this.Controls.Add(this.NameLabel);
            this.Controls.Add(this.HeaderLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimumSize = new System.Drawing.Size(680, 420);
            this.Name = "ReturnTicketForm";
            this.Text = "Повернення квитка";
            this.Load += new System.EventHandler(this.ReturnTicketForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label HeaderLabel;
        private System.Windows.Forms.TextBox DocumentIDTextBox;
        private System.Windows.Forms.TextBox SurnameTextBox;
        private System.Windows.Forms.TextBox NameTextBox;
        private System.Windows.Forms.Label PersonIDLabel;
        private System.Windows.Forms.Label SurnameLabel;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Button ReturnTicketButton;
        private System.Windows.Forms.Label TicketIDLabel;
        private System.Windows.Forms.MaskedTextBox TicketIDTextBox;
    }
}