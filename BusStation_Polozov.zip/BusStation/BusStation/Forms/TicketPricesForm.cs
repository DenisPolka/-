﻿using System;
using System.Windows.Forms;

namespace BusStation
{
    // Форма цен на билеты.
    public partial class TicketPricesForm : Form
    {
        public TicketPricesForm()
        {
            InitializeComponent();
        }

        // Форма.
        public static TicketPricesForm Form { get; set; }

        private void TicketPricesForm_Load(object sender, EventArgs e)
        {
            PricesDataGridView.DataSource = MainForm.PriceList.RoutePrices;
        }

        private void PricesDataGridView_CellValidating
            (object sender, DataGridViewCellValidatingEventArgs e)
        {
            string columnName =
                PricesDataGridView.Columns[e.ColumnIndex].Name;
            string value = e.FormattedValue.ToString();

            switch(columnName)
            {
                case "TicketPrice":
                    try
                    {
                        if (Double.Parse(value) <= 0)
                        {
                            throw new FormatException();
                        }
                    }
                    catch (FormatException)
                    {
                        PricesDataGridView.Rows[e.RowIndex].ErrorText =
                            "Ціна квитка не є числом, більшим за 0.";
                        e.Cancel = true;
                    }
                    catch (OverflowException)
                    {
                        PricesDataGridView.Rows[e.RowIndex].ErrorText =
                            "Число є дуже великим.";
                        e.Cancel = true;
                    }
                    break;

                case "destinationName":
                    if (String.IsNullOrEmpty(value))
                    {
                        PricesDataGridView.Rows[e.RowIndex].ErrorText =
                            "Порожня назва пункту призначення.";
                        e.Cancel = true;
                    }
                    break;
            }

            if (e.Cancel)
            {
                MessageBox.Show(
                    PricesDataGridView.Rows[e.RowIndex].ErrorText +
                    "\nДля відміни натисніть ESC.",
                    "Помилка",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void PricesDataGridView_CellEndEdit
            (object sender, DataGridViewCellEventArgs e)
        {
            PricesDataGridView.Rows[e.RowIndex].ErrorText = "";
            MainForm.PriceList.Write();
        }

        private void PricesDataGridView_RowsRemoved
            (object sender, DataGridViewRowsRemovedEventArgs e)
        {
            MainForm.PriceList.Write();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            Close();
            MainForm.Form.Show();
        }

        private void PricesDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void PricesDataGridView_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
