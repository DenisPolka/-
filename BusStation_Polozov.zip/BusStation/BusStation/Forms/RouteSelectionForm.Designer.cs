﻿namespace BusStation
{
    partial class RouteSelectionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RouteSelectionForm));
            this.SelectedRouteDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.destinationNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LeavingTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ArrivingTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TicketsAvailableDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TicketPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.selectedRoutesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.timetableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.BackButton = new System.Windows.Forms.Button();
            this.BookTicketButton = new System.Windows.Forms.Button();
            this.SelectRouteLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.SelectedRouteDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.selectedRoutesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.timetableBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // SelectedRouteDataGridView
            // 
            this.SelectedRouteDataGridView.AllowUserToAddRows = false;
            this.SelectedRouteDataGridView.AllowUserToDeleteRows = false;
            this.SelectedRouteDataGridView.AllowUserToResizeColumns = false;
            this.SelectedRouteDataGridView.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SelectedRouteDataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.SelectedRouteDataGridView.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.SelectedRouteDataGridView.AutoGenerateColumns = false;
            this.SelectedRouteDataGridView.BackgroundColor = System.Drawing.SystemColors.Control;
            this.SelectedRouteDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.SelectedRouteDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.SelectedRouteDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.SelectedRouteDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.destinationNameDataGridViewTextBoxColumn,
            this.LeavingTime,
            this.ArrivingTime,
            this.TicketsAvailableDataGridViewTextBoxColumn,
            this.TicketPriceDataGridViewTextBoxColumn});
            this.SelectedRouteDataGridView.DataSource = this.selectedRoutesBindingSource;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.SelectedRouteDataGridView.DefaultCellStyle = dataGridViewCellStyle3;
            this.SelectedRouteDataGridView.Location = new System.Drawing.Point(22, 67);
            this.SelectedRouteDataGridView.MultiSelect = false;
            this.SelectedRouteDataGridView.Name = "SelectedRouteDataGridView";
            this.SelectedRouteDataGridView.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.SelectedRouteDataGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.SelectedRouteDataGridView.Size = new System.Drawing.Size(835, 209);
            this.SelectedRouteDataGridView.TabIndex = 1;
            this.SelectedRouteDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.SelectedRouteDataGridView_CellContentClick);
            this.SelectedRouteDataGridView.SelectionChanged += new System.EventHandler(this.SelectedRouteDataGridView_SelectionChanged);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.dataGridViewTextBoxColumn1.DataPropertyName = "RouteNumber";
            this.dataGridViewTextBoxColumn1.HeaderText = "Рейс";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 67;
            // 
            // destinationNameDataGridViewTextBoxColumn
            // 
            this.destinationNameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.destinationNameDataGridViewTextBoxColumn.DataPropertyName = "EndPointName";
            this.destinationNameDataGridViewTextBoxColumn.HeaderText = "Пункт призначення";
            this.destinationNameDataGridViewTextBoxColumn.Name = "destinationNameDataGridViewTextBoxColumn";
            this.destinationNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.destinationNameDataGridViewTextBoxColumn.Width = 162;
            // 
            // LeavingTime
            // 
            this.LeavingTime.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.LeavingTime.DataPropertyName = "LeavingTime";
            this.LeavingTime.HeaderText = "Дата і час відправлення";
            this.LeavingTime.Name = "LeavingTime";
            this.LeavingTime.ReadOnly = true;
            this.LeavingTime.Width = 188;
            // 
            // ArrivingTime
            // 
            this.ArrivingTime.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.ArrivingTime.DataPropertyName = "ArrivingTime";
            this.ArrivingTime.HeaderText = "Дата і час прибуття";
            this.ArrivingTime.Name = "ArrivingTime";
            this.ArrivingTime.ReadOnly = true;
            this.ArrivingTime.Width = 161;
            // 
            // TicketsAvailableDataGridViewTextBoxColumn
            // 
            this.TicketsAvailableDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.TicketsAvailableDataGridViewTextBoxColumn.DataPropertyName = "TicketsFree";
            this.TicketsAvailableDataGridViewTextBoxColumn.HeaderText = "Вільні місця";
            this.TicketsAvailableDataGridViewTextBoxColumn.Name = "TicketsAvailableDataGridViewTextBoxColumn";
            this.TicketsAvailableDataGridViewTextBoxColumn.ReadOnly = true;
            this.TicketsAvailableDataGridViewTextBoxColumn.Width = 112;
            // 
            // TicketPriceDataGridViewTextBoxColumn
            // 
            this.TicketPriceDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.TicketPriceDataGridViewTextBoxColumn.DataPropertyName = "TicketPrice";
            this.TicketPriceDataGridViewTextBoxColumn.HeaderText = "Ціна, грн";
            this.TicketPriceDataGridViewTextBoxColumn.Name = "TicketPriceDataGridViewTextBoxColumn";
            this.TicketPriceDataGridViewTextBoxColumn.ReadOnly = true;
            this.TicketPriceDataGridViewTextBoxColumn.Width = 90;
            // 
            // selectedRoutesBindingSource
            // 
            this.selectedRoutesBindingSource.DataMember = "SearchedData";
            this.selectedRoutesBindingSource.DataSource = this.timetableBindingSource;
            // 
            // timetableBindingSource
            // 
            this.timetableBindingSource.DataSource = typeof(BusStation.RouteList);
            // 
            // BackButton
            // 
            this.BackButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.BackButton.BackColor = System.Drawing.SystemColors.Control;
            this.BackButton.Font = new System.Drawing.Font("Cambria", 16F);
            this.BackButton.Location = new System.Drawing.Point(465, 414);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(116, 42);
            this.BackButton.TabIndex = 2;
            this.BackButton.Text = "Назад";
            this.BackButton.UseVisualStyleBackColor = false;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // BookTicketButton
            // 
            this.BookTicketButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.BookTicketButton.BackColor = System.Drawing.SystemColors.Control;
            this.BookTicketButton.Font = new System.Drawing.Font("Cambria", 16F);
            this.BookTicketButton.Location = new System.Drawing.Point(601, 414);
            this.BookTicketButton.Name = "BookTicketButton";
            this.BookTicketButton.Size = new System.Drawing.Size(240, 42);
            this.BookTicketButton.TabIndex = 3;
            this.BookTicketButton.Text = "Замовити квиток";
            this.BookTicketButton.UseVisualStyleBackColor = false;
            this.BookTicketButton.Click += new System.EventHandler(this.BookTicketButton_Click);
            // 
            // SelectRouteLabel
            // 
            this.SelectRouteLabel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.SelectRouteLabel.AutoSize = true;
            this.SelectRouteLabel.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SelectRouteLabel.Location = new System.Drawing.Point(317, 15);
            this.SelectRouteLabel.Name = "SelectRouteLabel";
            this.SelectRouteLabel.Size = new System.Drawing.Size(218, 28);
            this.SelectRouteLabel.TabIndex = 4;
            this.SelectRouteLabel.Text = "Виберіть маршрут:";
            // 
            // RouteSelectionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(869, 489);
            this.Controls.Add(this.SelectRouteLabel);
            this.Controls.Add(this.BookTicketButton);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.SelectedRouteDataGridView);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "RouteSelectionForm";
            this.Text = "Вибір маршруту";
            this.Load += new System.EventHandler(this.RouteSelectionForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.SelectedRouteDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.selectedRoutesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.timetableBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView SelectedRouteDataGridView;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Button BookTicketButton;
        private System.Windows.Forms.Label SelectRouteLabel;
        private System.Windows.Forms.BindingSource selectedRoutesBindingSource;
        private System.Windows.Forms.BindingSource timetableBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn destinationNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn LeavingTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn ArrivingTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn TicketsAvailableDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn TicketPriceDataGridViewTextBoxColumn;
    }
}