﻿namespace BusStation
{
    partial class PassengerListForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PassengerListForm));
            this.PassangerListDataGridView = new System.Windows.Forms.DataGridView();
            this.Place = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.entriesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.passengerListBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.BackButton = new System.Windows.Forms.Button();
            this.HeaderLabel = new System.Windows.Forms.Label();
            this.deleteCancelledButton = new System.Windows.Forms.Button();
            this.documentIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.surnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TicketIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TicketPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.arrivalDateTimeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.departureDateTimeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.destinationNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.routeNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.PassangerListDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.entriesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.passengerListBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // PassangerListDataGridView
            // 
            this.PassangerListDataGridView.AllowUserToAddRows = false;
            this.PassangerListDataGridView.AllowUserToDeleteRows = false;
            this.PassangerListDataGridView.AllowUserToResizeColumns = false;
            this.PassangerListDataGridView.AllowUserToResizeRows = false;
            this.PassangerListDataGridView.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.PassangerListDataGridView.AutoGenerateColumns = false;
            this.PassangerListDataGridView.BackgroundColor = System.Drawing.SystemColors.Control;
            this.PassangerListDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.PassangerListDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.PassangerListDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.PassangerListDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.routeNumberDataGridViewTextBoxColumn,
            this.destinationNameDataGridViewTextBoxColumn,
            this.departureDateTimeDataGridViewTextBoxColumn,
            this.arrivalDateTimeDataGridViewTextBoxColumn,
            this.TicketPriceDataGridViewTextBoxColumn,
            this.TicketIDDataGridViewTextBoxColumn,
            this.Place,
            this.nameDataGridViewTextBoxColumn,
            this.surnameDataGridViewTextBoxColumn,
            this.documentIDDataGridViewTextBoxColumn,
            this.Status});
            this.PassangerListDataGridView.DataSource = this.entriesBindingSource;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.PassangerListDataGridView.DefaultCellStyle = dataGridViewCellStyle2;
            this.PassangerListDataGridView.Location = new System.Drawing.Point(56, 85);
            this.PassangerListDataGridView.Name = "PassangerListDataGridView";
            this.PassangerListDataGridView.ReadOnly = true;
            this.PassangerListDataGridView.Size = new System.Drawing.Size(1303, 531);
            this.PassangerListDataGridView.TabIndex = 0;
            this.PassangerListDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.PassangerListDataGridView_CellContentClick);
            this.PassangerListDataGridView.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.PassangerListDataGridView_CellValueChanged);
            // 
            // Place
            // 
            this.Place.DataPropertyName = "Place";
            this.Place.Frozen = true;
            this.Place.HeaderText = "Місце";
            this.Place.Name = "Place";
            this.Place.ReadOnly = true;
            this.Place.Width = 75;
            // 
            // Status
            // 
            this.Status.DataPropertyName = "Status";
            this.Status.HeaderText = "Стан";
            this.Status.Name = "Status";
            this.Status.ReadOnly = true;
            // 
            // entriesBindingSource
            // 
            this.entriesBindingSource.DataMember = "BuyerData";
            this.entriesBindingSource.DataSource = this.passengerListBindingSource;
            // 
            // passengerListBindingSource
            // 
            this.passengerListBindingSource.DataSource = typeof(BusStation.BuyerList);
            // 
            // BackButton
            // 
            this.BackButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.BackButton.BackColor = System.Drawing.SystemColors.Control;
            this.BackButton.Font = new System.Drawing.Font("Cambria", 16F);
            this.BackButton.Location = new System.Drawing.Point(1272, 645);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(129, 43);
            this.BackButton.TabIndex = 15;
            this.BackButton.Text = "Назад";
            this.BackButton.UseVisualStyleBackColor = false;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // HeaderLabel
            // 
            this.HeaderLabel.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.HeaderLabel.AutoSize = true;
            this.HeaderLabel.Font = new System.Drawing.Font("Cambria", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.HeaderLabel.Location = new System.Drawing.Point(598, 42);
            this.HeaderLabel.Name = "HeaderLabel";
            this.HeaderLabel.Size = new System.Drawing.Size(207, 25);
            this.HeaderLabel.TabIndex = 16;
            this.HeaderLabel.Text = "Посадкова відомість";
            // 
            // deleteCancelledButton
            // 
            this.deleteCancelledButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.deleteCancelledButton.BackColor = System.Drawing.SystemColors.Control;
            this.deleteCancelledButton.Font = new System.Drawing.Font("Cambria", 16F);
            this.deleteCancelledButton.Location = new System.Drawing.Point(21, 645);
            this.deleteCancelledButton.Name = "deleteCancelledButton";
            this.deleteCancelledButton.Size = new System.Drawing.Size(269, 43);
            this.deleteCancelledButton.TabIndex = 17;
            this.deleteCancelledButton.Text = "Видалити скасовані";
            this.deleteCancelledButton.UseVisualStyleBackColor = false;
            this.deleteCancelledButton.Click += new System.EventHandler(this.deleteCancelledButton_Click);
            // 
            // documentIDDataGridViewTextBoxColumn
            // 
            this.documentIDDataGridViewTextBoxColumn.DataPropertyName = "BuyerID";
            this.documentIDDataGridViewTextBoxColumn.HeaderText = "Номер та серія документа";
            this.documentIDDataGridViewTextBoxColumn.Name = "documentIDDataGridViewTextBoxColumn";
            this.documentIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // surnameDataGridViewTextBoxColumn
            // 
            this.surnameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.surnameDataGridViewTextBoxColumn.DataPropertyName = "Surname";
            this.surnameDataGridViewTextBoxColumn.Frozen = true;
            this.surnameDataGridViewTextBoxColumn.HeaderText = "Прізвище";
            this.surnameDataGridViewTextBoxColumn.Name = "surnameDataGridViewTextBoxColumn";
            this.surnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.surnameDataGridViewTextBoxColumn.Width = 103;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.Frozen = true;
            this.nameDataGridViewTextBoxColumn.HeaderText = "Ім\'я";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.ReadOnly = true;
            this.nameDataGridViewTextBoxColumn.Width = 63;
            // 
            // TicketIDDataGridViewTextBoxColumn
            // 
            this.TicketIDDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.TicketIDDataGridViewTextBoxColumn.DataPropertyName = "TicketID";
            this.TicketIDDataGridViewTextBoxColumn.Frozen = true;
            this.TicketIDDataGridViewTextBoxColumn.HeaderText = "Номер квитка";
            this.TicketIDDataGridViewTextBoxColumn.Name = "TicketIDDataGridViewTextBoxColumn";
            this.TicketIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.TicketIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // TicketPriceDataGridViewTextBoxColumn
            // 
            this.TicketPriceDataGridViewTextBoxColumn.DataPropertyName = "TicketPrice";
            this.TicketPriceDataGridViewTextBoxColumn.Frozen = true;
            this.TicketPriceDataGridViewTextBoxColumn.HeaderText = "Ціна, грн";
            this.TicketPriceDataGridViewTextBoxColumn.Name = "TicketPriceDataGridViewTextBoxColumn";
            this.TicketPriceDataGridViewTextBoxColumn.ReadOnly = true;
            this.TicketPriceDataGridViewTextBoxColumn.Width = 90;
            // 
            // arrivalDateTimeDataGridViewTextBoxColumn
            // 
            this.arrivalDateTimeDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.arrivalDateTimeDataGridViewTextBoxColumn.DataPropertyName = "ArrivingTime";
            this.arrivalDateTimeDataGridViewTextBoxColumn.Frozen = true;
            this.arrivalDateTimeDataGridViewTextBoxColumn.HeaderText = "Дата і час прибуття";
            this.arrivalDateTimeDataGridViewTextBoxColumn.Name = "arrivalDateTimeDataGridViewTextBoxColumn";
            this.arrivalDateTimeDataGridViewTextBoxColumn.ReadOnly = true;
            this.arrivalDateTimeDataGridViewTextBoxColumn.Width = 161;
            // 
            // departureDateTimeDataGridViewTextBoxColumn
            // 
            this.departureDateTimeDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.departureDateTimeDataGridViewTextBoxColumn.DataPropertyName = "LeavingTime";
            this.departureDateTimeDataGridViewTextBoxColumn.Frozen = true;
            this.departureDateTimeDataGridViewTextBoxColumn.HeaderText = "Дата і час відправлення";
            this.departureDateTimeDataGridViewTextBoxColumn.Name = "departureDateTimeDataGridViewTextBoxColumn";
            this.departureDateTimeDataGridViewTextBoxColumn.ReadOnly = true;
            this.departureDateTimeDataGridViewTextBoxColumn.Width = 188;
            // 
            // destinationNameDataGridViewTextBoxColumn
            // 
            this.destinationNameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.destinationNameDataGridViewTextBoxColumn.DataPropertyName = "EndPointName";
            this.destinationNameDataGridViewTextBoxColumn.Frozen = true;
            this.destinationNameDataGridViewTextBoxColumn.HeaderText = "Пункт призначення";
            this.destinationNameDataGridViewTextBoxColumn.Name = "destinationNameDataGridViewTextBoxColumn";
            this.destinationNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.destinationNameDataGridViewTextBoxColumn.Width = 162;
            // 
            // routeNumberDataGridViewTextBoxColumn
            // 
            this.routeNumberDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.routeNumberDataGridViewTextBoxColumn.DataPropertyName = "RouteNumber";
            this.routeNumberDataGridViewTextBoxColumn.Frozen = true;
            this.routeNumberDataGridViewTextBoxColumn.HeaderText = "Рейс";
            this.routeNumberDataGridViewTextBoxColumn.Name = "routeNumberDataGridViewTextBoxColumn";
            this.routeNumberDataGridViewTextBoxColumn.ReadOnly = true;
            this.routeNumberDataGridViewTextBoxColumn.Width = 67;
            // 
            // PassengerListForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1427, 711);
            this.Controls.Add(this.deleteCancelledButton);
            this.Controls.Add(this.HeaderLabel);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.PassangerListDataGridView);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(1443, 750);
            this.Name = "PassengerListForm";
            this.Text = "Посадкова відомість";
            this.Load += new System.EventHandler(this.PassengerListForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PassangerListDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.entriesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.passengerListBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView PassangerListDataGridView;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Label HeaderLabel;
        private System.Windows.Forms.BindingSource entriesBindingSource;
        private System.Windows.Forms.BindingSource passengerListBindingSource;
        private System.Windows.Forms.Button deleteCancelledButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn Place;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.DataGridViewTextBoxColumn routeNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn destinationNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn departureDateTimeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn arrivalDateTimeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn TicketPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn TicketIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn surnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn documentIDDataGridViewTextBoxColumn;
    }
}