﻿namespace BusStation
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.TimetableDataGridView = new System.Windows.Forms.DataGridView();
            this.routesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ExitButton = new System.Windows.Forms.Button();
            this.InputDestLabel = new System.Windows.Forms.Label();
            this.InputDestTextBox = new System.Windows.Forms.TextBox();
            this.SearchRouteButton = new System.Windows.Forms.Button();
            this.ReturnTicketButton = new System.Windows.Forms.Button();
            this.AdminMenuStrip = new System.Windows.Forms.MenuStrip();
            this.PassengerListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.OpenPassListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TicketPricesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.OpenPricesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.PasswordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ChangePassToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.departureDateTimeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.arrivalDateTimeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.routeNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TicketsAvailableDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.transitNamesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TicketPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.destinationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AutorizationButton = new System.Windows.Forms.Button();
            this.StationLabel = new System.Windows.Forms.Label();
            this.routeNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.destination = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.transit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.departureDateTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.arrivalDateTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TicketsFree = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.timetableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.TimetableDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.routesBindingSource)).BeginInit();
            this.AdminMenuStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.timetableBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // TimetableDataGridView
            // 
            this.TimetableDataGridView.AllowUserToResizeColumns = false;
            this.TimetableDataGridView.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TimetableDataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.TimetableDataGridView.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.TimetableDataGridView.AutoGenerateColumns = false;
            this.TimetableDataGridView.BackgroundColor = System.Drawing.SystemColors.Control;
            this.TimetableDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.TimetableDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.TimetableDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TimetableDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.routeNumber,
            this.destination,
            this.transit,
            this.departureDateTime,
            this.arrivalDateTime,
            this.TicketsFree});
            this.TimetableDataGridView.DataSource = this.routesBindingSource;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.TimetableDataGridView.DefaultCellStyle = dataGridViewCellStyle3;
            this.TimetableDataGridView.Location = new System.Drawing.Point(27, 87);
            this.TimetableDataGridView.Name = "TimetableDataGridView";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.TimetableDataGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.TimetableDataGridView.Size = new System.Drawing.Size(1141, 408);
            this.TimetableDataGridView.TabIndex = 0;
            this.TimetableDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.TimetableDataGridView_CellContentClick);
            this.TimetableDataGridView.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.TimetableDataGridView_CellEndEdit);
            this.TimetableDataGridView.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.TimetableDataGridView_CellValidating);
            this.TimetableDataGridView.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.TimetableDataGridView_RowsRemoved);
            // 
            // routesBindingSource
            // 
            this.routesBindingSource.DataMember = "Routes";
            this.routesBindingSource.DataSource = this.timetableBindingSource;
            // 
            // ExitButton
            // 
            this.ExitButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.ExitButton.BackColor = System.Drawing.SystemColors.Control;
            this.ExitButton.Font = new System.Drawing.Font("Cambria", 16F);
            this.ExitButton.Location = new System.Drawing.Point(955, 537);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(112, 40);
            this.ExitButton.TabIndex = 3;
            this.ExitButton.Text = "Вихід";
            this.ExitButton.UseVisualStyleBackColor = false;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // InputDestLabel
            // 
            this.InputDestLabel.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.InputDestLabel.AutoSize = true;
            this.InputDestLabel.Font = new System.Drawing.Font("Cambria", 16.25F);
            this.InputDestLabel.Location = new System.Drawing.Point(70, 547);
            this.InputDestLabel.Name = "InputDestLabel";
            this.InputDestLabel.Size = new System.Drawing.Size(217, 26);
            this.InputDestLabel.TabIndex = 4;
            this.InputDestLabel.Text = "Пункт призначення:";
            // 
            // InputDestTextBox
            // 
            this.InputDestTextBox.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.InputDestTextBox.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.InputDestTextBox.Location = new System.Drawing.Point(302, 543);
            this.InputDestTextBox.Name = "InputDestTextBox";
            this.InputDestTextBox.Size = new System.Drawing.Size(259, 30);
            this.InputDestTextBox.TabIndex = 5;
            this.InputDestTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.InputDestTextBox_KeyDown);
            // 
            // SearchRouteButton
            // 
            this.SearchRouteButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.SearchRouteButton.BackColor = System.Drawing.SystemColors.Control;
            this.SearchRouteButton.Font = new System.Drawing.Font("Cambria", 16F);
            this.SearchRouteButton.Location = new System.Drawing.Point(592, 537);
            this.SearchRouteButton.Name = "SearchRouteButton";
            this.SearchRouteButton.Size = new System.Drawing.Size(111, 40);
            this.SearchRouteButton.TabIndex = 6;
            this.SearchRouteButton.Text = "Пошук";
            this.SearchRouteButton.UseVisualStyleBackColor = false;
            this.SearchRouteButton.Click += new System.EventHandler(this.SearchRouteButton_Click);
            // 
            // ReturnTicketButton
            // 
            this.ReturnTicketButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.ReturnTicketButton.BackColor = System.Drawing.SystemColors.Control;
            this.ReturnTicketButton.Font = new System.Drawing.Font("Cambria", 16F);
            this.ReturnTicketButton.Location = new System.Drawing.Point(709, 537);
            this.ReturnTicketButton.Name = "ReturnTicketButton";
            this.ReturnTicketButton.Size = new System.Drawing.Size(240, 40);
            this.ReturnTicketButton.TabIndex = 11;
            this.ReturnTicketButton.Text = "Повернення квитка";
            this.ReturnTicketButton.UseVisualStyleBackColor = false;
            this.ReturnTicketButton.Click += new System.EventHandler(this.ReturnTicketButton_Click);
            // 
            // AdminMenuStrip
            // 
            this.AdminMenuStrip.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AdminMenuStrip.BackColor = System.Drawing.SystemColors.Control;
            this.AdminMenuStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.AdminMenuStrip.Font = new System.Drawing.Font("Cambria", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AdminMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.PassengerListToolStripMenuItem,
            this.TicketPricesToolStripMenuItem,
            this.PasswordToolStripMenuItem});
            this.AdminMenuStrip.Location = new System.Drawing.Point(790, 9);
            this.AdminMenuStrip.Name = "AdminMenuStrip";
            this.AdminMenuStrip.Size = new System.Drawing.Size(385, 27);
            this.AdminMenuStrip.TabIndex = 13;
            this.AdminMenuStrip.Text = "menuStrip1";
            // 
            // PassengerListToolStripMenuItem
            // 
            this.PassengerListToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.OpenPassListToolStripMenuItem});
            this.PassengerListToolStripMenuItem.Font = new System.Drawing.Font("Cambria", 12F);
            this.PassengerListToolStripMenuItem.Name = "PassengerListToolStripMenuItem";
            this.PassengerListToolStripMenuItem.Size = new System.Drawing.Size(171, 23);
            this.PassengerListToolStripMenuItem.Text = "Посадкова відомість";
            // 
            // OpenPassListToolStripMenuItem
            // 
            this.OpenPassListToolStripMenuItem.Name = "OpenPassListToolStripMenuItem";
            this.OpenPassListToolStripMenuItem.Size = new System.Drawing.Size(180, 24);
            this.OpenPassListToolStripMenuItem.Text = "Відкрити";
            this.OpenPassListToolStripMenuItem.Click += new System.EventHandler(this.OpenPassListToolStripMenuItem_Click);
            // 
            // TicketPricesToolStripMenuItem
            // 
            this.TicketPricesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.OpenPricesToolStripMenuItem1});
            this.TicketPricesToolStripMenuItem.Font = new System.Drawing.Font("Cambria", 12F);
            this.TicketPricesToolStripMenuItem.Name = "TicketPricesToolStripMenuItem";
            this.TicketPricesToolStripMenuItem.Size = new System.Drawing.Size(131, 23);
            this.TicketPricesToolStripMenuItem.Text = "Ціни на квитки";
            // 
            // OpenPricesToolStripMenuItem1
            // 
            this.OpenPricesToolStripMenuItem1.Name = "OpenPricesToolStripMenuItem1";
            this.OpenPricesToolStripMenuItem1.Size = new System.Drawing.Size(145, 24);
            this.OpenPricesToolStripMenuItem1.Text = "Відкрити";
            this.OpenPricesToolStripMenuItem1.Click += new System.EventHandler(this.OpenPricesToolStripMenuItem1_Click);
            // 
            // PasswordToolStripMenuItem
            // 
            this.PasswordToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ChangePassToolStripMenuItem});
            this.PasswordToolStripMenuItem.Font = new System.Drawing.Font("Cambria", 12F);
            this.PasswordToolStripMenuItem.Name = "PasswordToolStripMenuItem";
            this.PasswordToolStripMenuItem.Size = new System.Drawing.Size(75, 23);
            this.PasswordToolStripMenuItem.Text = "Пароль";
            // 
            // ChangePassToolStripMenuItem
            // 
            this.ChangePassToolStripMenuItem.Name = "ChangePassToolStripMenuItem";
            this.ChangePassToolStripMenuItem.Size = new System.Drawing.Size(137, 24);
            this.ChangePassToolStripMenuItem.Text = "Змінити";
            this.ChangePassToolStripMenuItem.Click += new System.EventHandler(this.ChangePassToolStripMenuItem_Click);
            // 
            // departureDateTimeDataGridViewTextBoxColumn
            // 
            this.departureDateTimeDataGridViewTextBoxColumn.DataPropertyName = "LeavingTime";
            this.departureDateTimeDataGridViewTextBoxColumn.HeaderText = "LeavingTime";
            this.departureDateTimeDataGridViewTextBoxColumn.Name = "departureDateTimeDataGridViewTextBoxColumn";
            // 
            // arrivalDateTimeDataGridViewTextBoxColumn
            // 
            this.arrivalDateTimeDataGridViewTextBoxColumn.DataPropertyName = "ArrivingTime";
            this.arrivalDateTimeDataGridViewTextBoxColumn.HeaderText = "ArrivingTime";
            this.arrivalDateTimeDataGridViewTextBoxColumn.Name = "arrivalDateTimeDataGridViewTextBoxColumn";
            // 
            // routeNumberDataGridViewTextBoxColumn
            // 
            this.routeNumberDataGridViewTextBoxColumn.DataPropertyName = "RouteNumber";
            this.routeNumberDataGridViewTextBoxColumn.HeaderText = "RouteNumber";
            this.routeNumberDataGridViewTextBoxColumn.Name = "routeNumberDataGridViewTextBoxColumn";
            // 
            // TicketsAvailableDataGridViewTextBoxColumn
            // 
            this.TicketsAvailableDataGridViewTextBoxColumn.DataPropertyName = "TicketsFree";
            this.TicketsAvailableDataGridViewTextBoxColumn.HeaderText = "TicketsFree";
            this.TicketsAvailableDataGridViewTextBoxColumn.Name = "TicketsAvailableDataGridViewTextBoxColumn";
            // 
            // transitNamesDataGridViewTextBoxColumn
            // 
            this.transitNamesDataGridViewTextBoxColumn.DataPropertyName = "GoThroughStr";
            this.transitNamesDataGridViewTextBoxColumn.HeaderText = "GoThroughStr";
            this.transitNamesDataGridViewTextBoxColumn.Name = "transitNamesDataGridViewTextBoxColumn";
            // 
            // TicketPriceDataGridViewTextBoxColumn
            // 
            this.TicketPriceDataGridViewTextBoxColumn.DataPropertyName = "TicketPrice";
            this.TicketPriceDataGridViewTextBoxColumn.HeaderText = "TicketPrice";
            this.TicketPriceDataGridViewTextBoxColumn.Name = "TicketPriceDataGridViewTextBoxColumn";
            // 
            // destinationDataGridViewTextBoxColumn
            // 
            this.destinationDataGridViewTextBoxColumn.DataPropertyName = "Destination";
            this.destinationDataGridViewTextBoxColumn.HeaderText = "Destination";
            this.destinationDataGridViewTextBoxColumn.Name = "destinationDataGridViewTextBoxColumn";
            // 
            // AutorizationButton
            // 
            this.AutorizationButton.BackColor = System.Drawing.SystemColors.Control;
            this.AutorizationButton.Font = new System.Drawing.Font("Cambria", 16F);
            this.AutorizationButton.Location = new System.Drawing.Point(27, 21);
            this.AutorizationButton.Name = "AutorizationButton";
            this.AutorizationButton.Size = new System.Drawing.Size(155, 37);
            this.AutorizationButton.TabIndex = 14;
            this.AutorizationButton.Text = "Авторизація";
            this.AutorizationButton.UseVisualStyleBackColor = false;
            this.AutorizationButton.Click += new System.EventHandler(this.AutorizationButton_Click);
            // 
            // StationLabel
            // 
            this.StationLabel.AutoSize = true;
            this.StationLabel.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StationLabel.Location = new System.Drawing.Point(486, 30);
            this.StationLabel.Name = "StationLabel";
            this.StationLabel.Size = new System.Drawing.Size(217, 28);
            this.StationLabel.TabIndex = 15;
            this.StationLabel.Text = "Автовокзал Харків";
            // 
            // routeNumber
            // 
            this.routeNumber.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.routeNumber.DataPropertyName = "RouteNumber";
            this.routeNumber.HeaderText = "Рейс";
            this.routeNumber.Name = "routeNumber";
            this.routeNumber.Width = 67;
            // 
            // destination
            // 
            this.destination.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.destination.DataPropertyName = "EndPointName";
            this.destination.HeaderText = "Пункт призначення";
            this.destination.Name = "destination";
            this.destination.Width = 162;
            // 
            // transit
            // 
            this.transit.DataPropertyName = "GoThroughStr";
            this.transit.HeaderText = "Проміжні пункти";
            this.transit.Name = "transit";
            this.transit.Width = 400;
            // 
            // departureDateTime
            // 
            this.departureDateTime.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.departureDateTime.DataPropertyName = "LeavingTime";
            this.departureDateTime.HeaderText = "Дата і час відправлення";
            this.departureDateTime.Name = "departureDateTime";
            this.departureDateTime.Width = 188;
            // 
            // arrivalDateTime
            // 
            this.arrivalDateTime.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.arrivalDateTime.DataPropertyName = "ArrivingTime";
            this.arrivalDateTime.HeaderText = "Дата і час прибуття";
            this.arrivalDateTime.Name = "arrivalDateTime";
            this.arrivalDateTime.Width = 161;
            // 
            // TicketsFree
            // 
            this.TicketsFree.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.TicketsFree.DataPropertyName = "TicketsFree";
            this.TicketsFree.HeaderText = "Вільні місця";
            this.TicketsFree.Name = "TicketsFree";
            this.TicketsFree.ReadOnly = true;
            this.TicketsFree.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.TicketsFree.Width = 112;
            // 
            // timetableBindingSource
            // 
            this.timetableBindingSource.DataSource = typeof(BusStation.RouteList);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1184, 611);
            this.Controls.Add(this.StationLabel);
            this.Controls.Add(this.AutorizationButton);
            this.Controls.Add(this.ReturnTicketButton);
            this.Controls.Add(this.SearchRouteButton);
            this.Controls.Add(this.InputDestTextBox);
            this.Controls.Add(this.InputDestLabel);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.TimetableDataGridView);
            this.Controls.Add(this.AdminMenuStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.AdminMenuStrip;
            this.MinimumSize = new System.Drawing.Size(1200, 650);
            this.Name = "MainForm";
            this.Text = "Каса автовокзалу";
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.TimetableDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.routesBindingSource)).EndInit();
            this.AdminMenuStrip.ResumeLayout(false);
            this.AdminMenuStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.timetableBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView TimetableDataGridView;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Label InputDestLabel;
        private System.Windows.Forms.TextBox InputDestTextBox;
        private System.Windows.Forms.Button SearchRouteButton;
        private System.Windows.Forms.Button ReturnTicketButton;
        private System.Windows.Forms.BindingSource timetableBindingSource;
        private System.Windows.Forms.MenuStrip AdminMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem PassengerListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem TicketPricesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem OpenPassListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem OpenPricesToolStripMenuItem1;
        private System.Windows.Forms.DataGridViewTextBoxColumn departureDateTimeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn arrivalDateTimeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn routeNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn TicketsAvailableDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn transitNamesDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn destinationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn TicketPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource routesBindingSource;
        private System.Windows.Forms.Button AutorizationButton;
        private System.Windows.Forms.ToolStripMenuItem PasswordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ChangePassToolStripMenuItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn routeNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn destination;
        private System.Windows.Forms.DataGridViewTextBoxColumn transit;
        private System.Windows.Forms.DataGridViewTextBoxColumn departureDateTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn arrivalDateTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn TicketsFree;
        private System.Windows.Forms.Label StationLabel;
    }
}

