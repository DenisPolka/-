﻿namespace BusStation
{
    partial class PasswordChangeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PasswordChangeForm));
            this.NewPassTextBox = new System.Windows.Forms.TextBox();
            this.CurrentPassTextBox = new System.Windows.Forms.TextBox();
            this.ConfirmPassTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.ConfirmPassButton = new System.Windows.Forms.Button();
            this.BackButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // NewPassTextBox
            // 
            this.NewPassTextBox.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NewPassTextBox.Location = new System.Drawing.Point(209, 89);
            this.NewPassTextBox.Name = "NewPassTextBox";
            this.NewPassTextBox.PasswordChar = '•';
            this.NewPassTextBox.Size = new System.Drawing.Size(272, 30);
            this.NewPassTextBox.TabIndex = 1;
            this.NewPassTextBox.TextChanged += new System.EventHandler(this.NewPassTextBox_TextChanged);
            // 
            // CurrentPassTextBox
            // 
            this.CurrentPassTextBox.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CurrentPassTextBox.Location = new System.Drawing.Point(209, 25);
            this.CurrentPassTextBox.Name = "CurrentPassTextBox";
            this.CurrentPassTextBox.PasswordChar = '•';
            this.CurrentPassTextBox.Size = new System.Drawing.Size(272, 30);
            this.CurrentPassTextBox.TabIndex = 2;
            // 
            // ConfirmPassTextBox
            // 
            this.ConfirmPassTextBox.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ConfirmPassTextBox.Location = new System.Drawing.Point(209, 150);
            this.ConfirmPassTextBox.Name = "ConfirmPassTextBox";
            this.ConfirmPassTextBox.PasswordChar = '•';
            this.ConfirmPassTextBox.Size = new System.Drawing.Size(272, 30);
            this.ConfirmPassTextBox.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(36, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 22);
            this.label1.TabIndex = 4;
            this.label1.Text = "Поточний пароль:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(67, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 22);
            this.label2.TabIndex = 5;
            this.label2.Text = "Новий пароль:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(6, 153);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(197, 22);
            this.label3.TabIndex = 6;
            this.label3.Text = "Новий пароль ще раз:";
            // 
            // ConfirmPassButton
            // 
            this.ConfirmPassButton.BackColor = System.Drawing.SystemColors.Control;
            this.ConfirmPassButton.Font = new System.Drawing.Font("Cambria", 16F);
            this.ConfirmPassButton.Location = new System.Drawing.Point(232, 215);
            this.ConfirmPassButton.Name = "ConfirmPassButton";
            this.ConfirmPassButton.Size = new System.Drawing.Size(166, 38);
            this.ConfirmPassButton.TabIndex = 8;
            this.ConfirmPassButton.Text = "Підтвердити";
            this.ConfirmPassButton.UseVisualStyleBackColor = false;
            this.ConfirmPassButton.Click += new System.EventHandler(this.ConfirmPassButton_Click);
            // 
            // BackButton
            // 
            this.BackButton.BackColor = System.Drawing.SystemColors.Control;
            this.BackButton.Font = new System.Drawing.Font("Cambria", 16F);
            this.BackButton.Location = new System.Drawing.Point(98, 215);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(109, 38);
            this.BackButton.TabIndex = 9;
            this.BackButton.Text = "Назад";
            this.BackButton.UseVisualStyleBackColor = false;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // PasswordChangeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(509, 276);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.ConfirmPassButton);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ConfirmPassTextBox);
            this.Controls.Add(this.CurrentPassTextBox);
            this.Controls.Add(this.NewPassTextBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PasswordChangeForm";
            this.Text = "Змінити пароль";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.PasswordChangeForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox NewPassTextBox;
        private System.Windows.Forms.TextBox CurrentPassTextBox;
        private System.Windows.Forms.TextBox ConfirmPassTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button ConfirmPassButton;
        private System.Windows.Forms.Button BackButton;
    }
}