﻿namespace BusStation
{
    partial class AutorizationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AutorizationForm));
            this.PasswordTextBox = new System.Windows.Forms.TextBox();
            this.EnterPassLabel = new System.Windows.Forms.Label();
            this.EnterPassButton = new System.Windows.Forms.Button();
            this.UnautorizedButton = new System.Windows.Forms.Button();
            this.AutorizedLabel = new System.Windows.Forms.Label();
            this.BackButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // PasswordTextBox
            // 
            this.PasswordTextBox.Font = new System.Drawing.Font("Cambria", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PasswordTextBox.Location = new System.Drawing.Point(96, 56);
            this.PasswordTextBox.Name = "PasswordTextBox";
            this.PasswordTextBox.PasswordChar = '•';
            this.PasswordTextBox.Size = new System.Drawing.Size(341, 30);
            this.PasswordTextBox.TabIndex = 0;
            this.PasswordTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PasswordTextBox_KeyDown);
            // 
            // EnterPassLabel
            // 
            this.EnterPassLabel.AutoSize = true;
            this.EnterPassLabel.Font = new System.Drawing.Font("Cambria", 16.25F);
            this.EnterPassLabel.Location = new System.Drawing.Point(179, 18);
            this.EnterPassLabel.Name = "EnterPassLabel";
            this.EnterPassLabel.Size = new System.Drawing.Size(169, 26);
            this.EnterPassLabel.TabIndex = 1;
            this.EnterPassLabel.Text = "Введіть пароль:";
            // 
            // EnterPassButton
            // 
            this.EnterPassButton.BackColor = System.Drawing.SystemColors.Control;
            this.EnterPassButton.Font = new System.Drawing.Font("Cambria", 16F);
            this.EnterPassButton.Location = new System.Drawing.Point(213, 107);
            this.EnterPassButton.Name = "EnterPassButton";
            this.EnterPassButton.Size = new System.Drawing.Size(102, 41);
            this.EnterPassButton.TabIndex = 7;
            this.EnterPassButton.Text = "Увійти";
            this.EnterPassButton.UseVisualStyleBackColor = false;
            this.EnterPassButton.Click += new System.EventHandler(this.EnterPassButton_Click);
            // 
            // UnautorizedButton
            // 
            this.UnautorizedButton.BackColor = System.Drawing.SystemColors.Control;
            this.UnautorizedButton.Font = new System.Drawing.Font("Cambria", 16F);
            this.UnautorizedButton.Location = new System.Drawing.Point(57, 171);
            this.UnautorizedButton.Name = "UnautorizedButton";
            this.UnautorizedButton.Size = new System.Drawing.Size(265, 39);
            this.UnautorizedButton.TabIndex = 8;
            this.UnautorizedButton.Text = "Продовжити як клієнт";
            this.UnautorizedButton.UseVisualStyleBackColor = false;
            this.UnautorizedButton.Click += new System.EventHandler(this.UnautorizedButton_Click);
            // 
            // AutorizedLabel
            // 
            this.AutorizedLabel.AutoSize = true;
            this.AutorizedLabel.Font = new System.Drawing.Font("Cambria", 16.25F);
            this.AutorizedLabel.Location = new System.Drawing.Point(105, 89);
            this.AutorizedLabel.Name = "AutorizedLabel";
            this.AutorizedLabel.Size = new System.Drawing.Size(321, 26);
            this.AutorizedLabel.TabIndex = 9;
            this.AutorizedLabel.Text = "Ви авторизовані як диспетчер.";
            this.AutorizedLabel.Visible = false;
            this.AutorizedLabel.Click += new System.EventHandler(this.AutorizedLabel_Click);
            // 
            // BackButton
            // 
            this.BackButton.BackColor = System.Drawing.SystemColors.Control;
            this.BackButton.Font = new System.Drawing.Font("Cambria", 16F);
            this.BackButton.Location = new System.Drawing.Point(367, 171);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(101, 39);
            this.BackButton.TabIndex = 10;
            this.BackButton.Text = "Назад";
            this.BackButton.UseVisualStyleBackColor = false;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // AutorizationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(523, 228);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.AutorizedLabel);
            this.Controls.Add(this.UnautorizedButton);
            this.Controls.Add(this.EnterPassButton);
            this.Controls.Add(this.EnterPassLabel);
            this.Controls.Add(this.PasswordTextBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AutorizationForm";
            this.Text = "Авторизація";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.AutorizationForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox PasswordTextBox;
        private System.Windows.Forms.Label EnterPassLabel;
        private System.Windows.Forms.Button EnterPassButton;
        private System.Windows.Forms.Button UnautorizedButton;
        private System.Windows.Forms.Label AutorizedLabel;
        private System.Windows.Forms.Button BackButton;
    }
}