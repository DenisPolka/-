﻿using System;
using System.ComponentModel;
using Newtonsoft.Json;
using System.IO;
using System.Text;

namespace BusStation
{
    //Класс цен на билеты.
    public class TicketPrice
    {
        // Список цен на билеты.
        public BindingList<Point> RoutePrices { get; set; }

        // Конструктор.
        public TicketPrice()
        {
            Read();
        }

        // Считывание цен на билеты из файла.
        public void Read()
        {
            RoutePrices = new BindingList<Point>();
            string[,] data =JsonConvert.DeserializeObject<string[,]>
                (Encoding.UTF8.GetString(File.ReadAllBytes("TicketPrices.json")));
            var length = data.GetUpperBound(0) + 1;

            if (data == null)
            {
                return;
            }

            for (var i = 0; i < length; ++i)
            {
                Point pointCost = new Point(data[i, 0], Double.Parse(data[i, 1]));

                RoutePrices.Add(pointCost);
            }
        }

        // Запись цен на билеты в файл.
        public void Write()
        {
            string[,] data = new string[RoutePrices.Count, 2];

            var n = 0;  // Номер цены.
            foreach (var point in RoutePrices)
            {
                data[n, 0] = point.EndPointName;
                data[n, 1] = point.TicketPrice.ToString();
                ++n;
            }

            File.WriteAllText("TicketPrices.json", JsonConvert.SerializeObject(data));
        }

        // Поиск цены билета по названию конечного пункта.
        public double SearchCost(string value)
        {
            double cost = 9;    // Дефолтная цена.

            foreach (var data in RoutePrices)
            {
                if (value == data.EndPointName)
                {
                    cost = data.TicketPrice;
                    break;
                }
            }
            return cost;
        }
    }
}
